#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Thu Feb 20 18:19:35 2020

@author: root
"""


import cv2
import numpy as np

from picamera import PiCamera
from time import sleep
from matplotlib import pyplot as plt
from skimage import measure
from sense_hat import SenseHat
import time
import threading
from tkinter import *
import tkinter as tk
from tkinter import ttk
from threading import Lock
from pynput import keyboard as kb
import thingspeak

#Activa sensores
sense=SenseHat()
camera = PiCamera()
#Definición de variables globales
limiteVel = 0
tipoSenal = 1
vel = 0
refVel=10
e_1=0
vel_1=0
modo=0
numIncumplidas=0
lockRef=threading.Lock()


O=[255,0,0]
X=[255,255,255]
V=[0,255,0]
EXCESO = [
O, O, O, X, X, O, O, O,
O, O, O, X, X, O, O, O,
O, O, O, X, X, O, O, O,
O, O, O, X, X, O, O, O,
O, O, O, X, X, O, O, O,
O, O, O, O, O, O, O, O,
O, O, O, X, X, O, O, O,
O, O, O, X, X, O, O, O,
]

def camara():
    #Definición de variables globales
    global limiteVel
    global tipoSenal
    global lockRef
    #Inicialización de variables locales
    posibleSenal = 0
    numElementos = 0
    porcAnt = 100
    
    while True:
        #Cuenta 5 y realiza una foto
        #print ('Realizando análisis del entorno')
        camera.resolution = (640,480)
        camera.rotation = 180
        camera.start_preview(fullscreen=False, window=(30,30,320,240))
        for i in range(0,5):
            print (5-i)
            sleep(1)
        camera.capture('/home/pi/Desktop/IoT/imagenOriginal.jpg')
        #camera.stop_preview()
        #camera.close()

        #Lee la foto 
        im=cv2.imread('imagenOriginal.jpg')
        #La pasa a escala de grises
        gris=cv2.cvtColor(im,cv2.COLOR_BGR2GRAY)
        #Le realiza un filtro gaussiano a la imagen en gris
        desen=cv2.GaussianBlur(gris,(7,7),cv2.BORDER_DEFAULT)
        #La binariza quedandose con los tonos deseados
        ret,th1=cv2.threshold(desen,127,255,cv2.THRESH_BINARY)
        #Obtiene los posibles contornos
        contornos,hierarchy=cv2.findContours(th1,cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)

        #Recorre los diferentes contornos
        for cnt in contornos :
            #Si el área supera el umbral
            if cv2.contourArea(cnt) > 10000:
                #Obtiene su BBox
                x,y,w,h = cv2.boundingRect(cnt)
                crop=im[y:y+h,x:x+w] 
                dsize=(500,500)
                #Recorta la imagen
                imagenOriginal=cv2.resize(crop,dsize)
                #La paso a escala de grises y la binarizo
                originalGris=cv2.cvtColor(imagenOriginal,cv2.COLOR_BGR2GRAY)
                ret,originalTh=cv2.threshold(originalGris,127,255,cv2.THRESH_BINARY_INV)
                #Variable que indica que se ha detectado una posible señal
                posibleSenal = 1
                    
        #Obtener los números que aparecen en la señal
        if posibleSenal == 1:
            #Contar los objetos que aparecen en la imagen
            labels = measure.label(originalTh, connectivity=2, background=0)
            regionInteres = np.zeros(originalTh.shape, dtype='uint8')
            
            for i, label in enumerate(np.unique(labels)):
                #El primer objeto es siempre el fondo, se desprecia
                if label == 0:
                    continue        
                # Construimos una máscara para mostrar sólo las componentes conectadas de la etiqueta actual.
                label_mask = np.zeros(originalTh.shape, dtype='uint8')
                label_mask[labels == label] = 255
                num_pixels = cv2.countNonZero(label_mask)
                #print(num_pixels)
             
                # Si el número de píxeles en la componente es suficientemente larga, probablemente sea una región de interés,
                # por lo que la agregamos a nuestra máscara final.
                if ((num_pixels > 10000) & (num_pixels < 25000)) | (num_pixels > 100000):
                    regionInteres = cv2.add(regionInteres, label_mask)
                    numElementos = numElementos + 1
        
            #Si la región de interes es mayor de 1, se trata de una limitación de velocidad
            if numElementos > 1:
                cv2.imwrite('PosibleSenal.png', regionInteres)
                #lockRef.acquire()
                #Identificar cada número que aparece en la señal
                numeros = measure.label(regionInteres, connectivity=2, background=0)
                limiteVelAnt = limiteVel
                limiteVel = 0
                num_crop = 0
                for i, label in enumerate(np.unique(numeros)):
                    #El primer objeto es siempre el fondo, se desprecia
                    if label == 0:
                        continue
                    #Se obtiene un numero de la imagen utilizando una máscara
                    numero_mask = np.zeros(regionInteres.shape, dtype='uint8')
                    numero_mask[numeros == label] = 255
                    #Obtiene los posibles contornos
                    contornos,hierarchy=cv2.findContours(numero_mask,cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)
                    #Para cada posible contorno
                    for cnt in contornos :
                        #Si el área supera el umbral, recorta el digito por su BBox
                        if cv2.contourArea(cnt) > 10000:
                            x,y,w,h = cv2.boundingRect(cnt)
                            numCrop=numero_mask[y:y+h,x:x+w] 
                            dsize=(224,280)
                            numeroCrop=cv2.resize(numCrop,dsize)
                            num_crop = 1

                    #Comparo con las plantillas de los posibles numeros
                    porcAnt = 100
                    digito = 0
                    if(num_crop == 1):
                        for j in range(0,10):
                            indice = str(j)
                            nombrePlantilla = 'plantilla' + indice + '.png'
                            #Obtengo una plantilla, paso a escala de grises y la binarizo
                            imagenPlantilla=cv2.imread(nombrePlantilla)
                            plantilla=cv2.cvtColor(imagenPlantilla,cv2.COLOR_BGR2GRAY)
                            #Comparativa entre las dos imagenes
                            XOR=cv2.bitwise_xor(numeroCrop,plantilla)
                            x=cv2.countNonZero(XOR)
                            porcentaje=(x/250000.0)*100
                            #Guarda el valor del dígito que se parezca más
                            if porcentaje<porcAnt:
                                if porcentaje<9:
                                    digito = j
                                    porcAnt = porcentaje
                        #Actualiza el valor del límite de velocidad
                        if porcAnt < 9:
                            limiteVel = limiteVel*10 + digito
                #Corrección de errores si invierte los numeros
                if (limiteVel < 10):
                    limiteVel = limiteVel*10
                #Si realmente no ha detectado una señal
                if (limiteVel == 0) | (limiteVel > 90) | (limiteVel % 10 != 0):
                    limiteVel = limiteVelAnt
                    print('No se ha detectado ninguna señal')
                else:
                    #Informa por el sense hat y por la línea de comandos
                    print('El límite de velocidad es de %d km/h' % (limiteVel))
                    #cv2.imshow('Detectada', regionInteres)
                    cv2.waitKey()
                    cv2.imwrite('PosibleSenal.png', regionInteres)
                    sense.show_message(str(limiteVel),text_colour=[100,100,100])
                    sleep(2)
                    sense.clear()
                    #Durante 10 segundos entre capturas de pantalla, que compruebe si se actualizan los botones
                    sleep(1)
                #lockRef.release()        
            #En el caso en el que no se trate de limites de velocidad
            else:
                cv2.imwrite('PosibleSenal.png', regionInteres)
                #Comprobar si se trata de la señal de prohibido el paso
                imagenPlantilla=cv2.imread("plantillaProhibido.png")
                #Obtengo una plantilla, paso a escala de grises y la binarizo
                plantillaGris=cv2.cvtColor(imagenPlantilla,cv2.COLOR_BGR2GRAY)
                ret,plantillaTh=cv2.threshold(plantillaGris,127,255,cv2.THRESH_BINARY_INV)
                #Recorto la imagen original al tamaño de la plantilla
                originalThCrop=cv2.resize(originalTh,(225,225))
                #Comparativa entre las dos imagenes
                XOR=cv2.bitwise_xor(originalThCrop,plantillaTh)
                x=cv2.countNonZero(XOR)
                porcentaje=(x/250000.0)*100
                #Si hay menos del 5% de diferencia
                if porcentaje<5:
                    #print('Detectada una señal de prohibido el paso')
                    tipoSenal = 2
                    #cv2.imshow('Detectada', regionInteres)
                    cv2.waitKey()
                    cv2.imwrite('PosibleSenal.png', regionInteres)
                    #Durante 10 segundos entre capturas de pantalla, que compruebe si se actualizan los botones
                    sleep(10)
                else:
                    #Comprobar si se trata de la señal de sentido obligatorio derecho
                    imagenPlantilla=cv2.imread("plantillaDerecha.png")
                    #Obtengo una plantilla, paso a escala de grises y la binarizo
                    plantillaGris=cv2.cvtColor(imagenPlantilla,cv2.COLOR_BGR2GRAY)
                    ret,plantillaTh=cv2.threshold(plantillaGris,127,255,cv2.THRESH_BINARY_INV)
                    #Comparativa entre las dos imagenes
                    XOR=cv2.bitwise_xor(originalTh,plantillaTh)
                    x=cv2.countNonZero(XOR)
                    porcentaje=(x/250000.0)*100
                    #Si hay menos del 15% de diferencia
                    if porcentaje<15:
                        #print('Detectada una señal de sentido obligatorio a la derecha')
                        tipoSenal = 3
                        #cv2.imshow('Detectada', regionInteres)
                        cv2.waitKey()
                        cv2.imwrite('PosibleSenal.png', regionInteres)
                        #Durante 10 segundos entre capturas de pantalla, que compruebe si se actualizan los botones
                        sleep(10)
                    #En caso contrario
                    else:
                        print('Se trata de un tipo de señal desconocida')
                        #sleep(10)
        #Si no, se indica que no se ha detectado ninguna señal
        else:
            print('No se ha detectado ninguna señal')
            #sleep(10)
        
        #Reinicio el valor de las variables
        posibleSenal = 0
        numElementos = 0
        sense.clear()
        
def joystick():
    #Definición de la pantalla de acción
    global X,O,V

    ERROR = [
    X, O, O, O, O, O, O, X,
    O, X, O, O, O, O, X, O,
    O, O, X, O, O, X, O, O,
    O, O, O, X, X, O, O, O,
    O, O, O, X, X, O, O, O,
    O, O, X, O, O, X, O, O,
    O, X, O, O, O, O, X, O,
    X, O, O, O, O, O, O, X,
    ]
    CONT = [
    V, V, V, V, V, V, V, X,
    V, V, V, V, V, V, X, V,
    V, V, V, V, V, X, X, V,
    V, X, V, V, X, X, V, V,
    V, X, X, X, X, V, V, V,
    V, V, X, X, V, V, V, V,
    V, V, V, X, V, V, V, V,
    V, V, V, V, V, V, V, V,
    ]
    MASR = [
    O, O, O, O, O, O, O, O,
    O, O, O, X, X, O, O, O,
    O, O, O, X, X, O, O, O,
    O, X, X, X, X, X, X, O,
    O, X, X, X, X, X, X, O,
    O, O, O, X, X, O, O, O,
    O, O, O, X, X, O, O, O,
    O, O, O, O, O, O, O, O,
    ]
    MASV = [
    V, V, V, V, V, V, V, V,
    V, V, V, X, X, V, V, V,
    V, V, V, X, X, V, V, V,
    V, X, X, X, X, X, X, V,
    V, X, X, X, X, X, X, V,
    V, V, V, X, X, V, V, V,
    V, V, V, X, X, V, V, V,
    V, V, V, V, V, V, V, V,
    ]
    MENOSR = [
    O, O, O, O, O, O, O, O,
    O, O, O, O, O, O, O, O,
    O, O, O, O, O, O, O, O,
    O, X, X, X, X, X, X, O,
    O, X, X, X, X, X, X, O,
    O, O, O, O, O, O, O, O,
    O, O, O, O, O, O, O, O,
    O, O, O, O, O, O, O, O,
    ]
    MENOSV = [
    V, V, V, V, V, V, V, V,
    V, V, V, V, V, V, V, V,
    V, V, V, V, V, V, V, V,
    V, X, X, X, X, X, X, V,
    V, X, X, X, X, X, X, V,
    V, V, V, V, V, V, V, V,
    V, V, V, V, V, V, V, V,
    V, V, V, V, V, V, V, V,
    ]

    #Definición de variables globales
    global limiteVel,refVel
    global tipoSenal
    global modo
    global numIncumplidas
    #Inicialización de variables
    global vel,vel_1 
    while True:
        for event in sense.stick.get_events():
            if (modo==0):
                if tipoSenal == 1:
                    #Actualizar la velocidad a la que se desplaza el vehiculo
                    if event.direction  == "up" and event.action == "pressed":
                        if vel > 115:
                            print('Se ha alcanzado la velocidad máxima: %d km/h' % (vel))
                        else:
                            vel = vel + 5
                            #Comporbar si va por encima del limite de velocidad
                            if vel > limiteVel and event.action == "pressed" and limiteVel != 0:
                                #print('Reduzca su velocidad (%d km/h) al limite de la vía: %d km/h' % (vel,limiteVel))
                                sense.set_pixels(EXCESO)
                                numIncumplidas=numIncumplidas+1
                                sleep(1)
                                sense.clear()
                            else:
                                #print('Velocidad del vehículo: %d km/h' % (vel))
                                sense.set_pixels(MASV)
                                sleep(1)
                                sense.clear()
                    elif event.direction  == "down" and event.action == "pressed":
                        if vel < 15:
                            print('Se ha alcanzado la velocidad mínima: %d km/h' % (vel))
                        else:
                            vel = vel - 5
                            #Comporbar si va por encima del limite de velocidad
                            if vel > limiteVel and event.action == "pressed" and limiteVel != 0:
                                #print('Reduzca su velocidad (%d km/h) al limite de la vía: %d km/h' % (vel,limiteVel))
                                sense.set_pixels(EXCESO)
                                numIncumplidas=numIncumplidas+1
                                sleep(1)
                                sense.clear()
                            else:
                                #print('Velocidad del vehículo: %d km/h' % (vel))
                                sense.set_pixels(MENOSV)
                                sleep(1)
                                sense.clear()
                    vel_1=vel
                    refVel=round(vel)
                
                elif tipoSenal == 2:
                    if event.direction  == "up" and event.action == "pressed":
                        #print('Prohibido el paso en esa dirección')
                        sense.set_pixels(ERROR)
                        sleep(2)
                        sense.clear()
                    elif event.action == "pressed":
                        #print('Dirección permitida, puede continuar')
                        sense.set_pixels(CONT)
                        sleep(2)
                        sense.clear()
                        tipoSenal = 1
                        
                elif tipoSenal == 3:
                    if event.direction  == "right" and event.action == "pressed":
                        #print('Dirección permitida, puede continuar')
                        sense.set_pixels(CONT)
                        sleep(2)
                        sense.clear()
                        tipoSenal = 1
                    elif event.action == "pressed":
                        #print('Prohibido el paso en esa dirección')
                        sense.set_pixels(ERROR)
                        sleep(2)
                        sense.clear()



##########################################
# Reconocimiento del teclado
##########################################
def teclado():
    global vel,limiteVel,refVel
    global modo
    global lockRef


    def pulsa(tecla):
        return

    def suelta(tecla):     
        global vel,limiteVel,refVel
        global lockRef,modo
        if (modo==1):
            if (tecla==kb.Key.up):
                #lockRef.acquire()
                if (refVel<120):                    
                    refVel=refVel+10
                    if (refVel>limiteVel):
                        sense.set_pixels(EXCESO)
                        sleep(1)
                        sense.clear()
                        #print('Alcanzado el limite maximo de velocidad') #Avisa pero no restringe
                else:
                    print('Se ha alcanzado la velocidad de referencia maxima: 120 km/h')
            elif (tecla==kb.Key.down):
                #lockRef.acquire()
                refVel=refVel-10
                if (refVel<10):
                    refVel=10
                    print('Se ha alcanzado la velocidad de referencia mínima: 10 km/h')
                else:
                    if (refVel>limiteVel):
                        sense.set_pixels(EXCESO)
                        sleep(1)
                        sense.clear()
            else:
                return
            #lockRef.release()
        else:
            return
        
    with kb.Listener(pulsa,suelta) as listener:
            listener.join()

##########################################
# Modo automatico (control de velocidad)
##########################################
def ctrl_velocidad():
    global modo
    global refVel
    global vel,vel_1, e_1
    if (modo==1):
        #lockRef.acquire()
        # PI discretizado
        vel=(vel_1+0.3*(refVel-vel)+0.19*e_1)
        vel=round(vel,2)
        if vel<0:
            vel=0
        elif vel>120:
            vel=120
        e_1=refVel-vel
        vel_1=vel

        #print('Velocidad actual: ' + str(vel))         
    threading.Timer(2,ctrl_velocidad).start()

##########################################
#Ventana
##########################################
def ventana():
    global limiteVel
    global lockRef
    global tipoSenal,refVel,vel
    global numIncumplidas
 
    def selec_modo():
        global modo
        modo=int(m.get())
    
    def mov_coche():
        plano2.place(x=214, y=222, width=87,height=77)
        threading.Timer(0.2,rst_pantalla,"1").start()
        return
        
    def rst_pantalla(*arg):
        if (arg[0]=='0'):
            dibujo_senal.place_forget() # señal
        elif (arg[0]=='1'):
            plano2.place_forget() #coche moviendose
            #threading.Timer(0.1,mov_coche).start()            
            
    def pinta(sen):
        dibujo_senal.place(x=0, y=100, width=140)
        if sen==20:
            dibujo_senal['image']=i20
        elif sen==30:
            dibujo_senal['image']=i30
        elif sen==40:
            dibujo_senal['image']=i40
        elif sen==50:
            dibujo_senal['image']=i50
        elif sen==60:
            dibujo_senal['image']=i60
        elif sen==70:
            dibujo_senal['image']=i70
        elif sen==80:
            dibujo_senal['image']=i80
        elif sen==90:
            dibujo_senal['image']=i90
        elif sen==3:
            dibujo_senal['image']=igr
        elif sen==2:
            dibujo_senal['image']=ipr
        threading.Timer(5,rst_pantalla,"0").start()

        
        
    def id_senal():
        global limiteVel,tipoSenal,refVel,vel
        senal_ant=limiteVel
        tipo_ant=1
        ref_ant=refVel
        vel_ant=1
        while True:
            #lockRef.acquire()
            if ((senal_ant!=limiteVel)and(tipoSenal==1)):
                #print('Señal anterior: '+str(senal_ant)+'Lim: ' +str(limiteVel))
                senal_ant=limiteVel
                pinta(senal_ant)
                
            if ((tipo_ant!=tipoSenal)and(tipoSenal!=1)):
                #print('Restriccion de movimiento')
                tipo_ant=tipoSenal
                pinta(tipo_ant)
                
            if ((ref_ant!=refVel)and(modo==1)):
                crucero.place(x=350,y=250)
                crucero['image']=icrucero
                ref_imprimir.config(text=str(refVel))
                ref_imprimir.place(x=400,y=250)
                ref_ant=refVel
            elif(modo==0):
                crucero.place_forget()
                ref_imprimir.place_forget()
                    
            #lockRef.release()
            if (vel_ant!=vel):
                numvelocimetro.config(text=str(round(vel)))
                if modo==1:
                    print('Velocidad actual del coche: '+str(vel))
                vel_ant=vel
                
    def envio_datos():
        global vel,numIncumplidas
        dato = vel
        dato2=numIncumplidas
        try:
            response = channel.update({"field1": dato,"field2":dato2})
            print("Velocidad enviada: " + str(dato)+'Num incumpl: '+str(dato2))
        except:
            print("connection failed")
        threading.Timer(15,envio_datos).start()
        


                        
    ventana = tk.Tk()
    ventana.config(width=500, height=340)
    ventana.title("Ventana")
    # Plano principal
    plano=ttk.Label(ventana)
    plano.place(x=0, y=0, width=500)
    iplano=PhotoImage(file='plano.png')
    plano['image']=iplano
    
    #Plano movimiento
    plano2=ttk.Label(plano)
    iplano2=PhotoImage(file='plano2.png')
    plano2['image']=iplano2
    plano2.place(x=214, y=222, width=87,height=77)
    
        #Icono velocidad de crucero
    crucero=ttk.Label(plano)
    icrucero=PhotoImage(file='icono.png')
    ref_imprimir=ttk.Label(plano,text=(str(refVel)+' '),background='white',relief=SUNKEN,font=('Arial',30))

    
    #Icono velocidad
    velocimetro=ttk.Label(plano)
    ivelocimetro=PhotoImage(file='velocimetro.png')
    velocimetro['image']=ivelocimetro
    velocimetro.place(x=370,y=50)
    numvelocimetro=ttk.Label(velocimetro,text=str(vel),background='black',foreground='white',font=('Arial',25))
    numvelocimetro.place(x=37,y=38) 

        # Modo de movimiento
    m=IntVar()
    modos=['Manual','Automatico']
    for i in range(2):
        rb_m=ttk.Radiobutton(plano,text=modos[i],variable=m,value=i,command=selec_modo)
        rb_m.place(x=0,y=(0+30*i),width=100,height=30)
 
    #Señales
    dibujo_senal=ttk.Label(plano)
    i10=PhotoImage(file='20.png')
    i20=PhotoImage(file='20.png')
    i30=PhotoImage(file='30.png')
    i40=PhotoImage(file='40.png')
    i50=PhotoImage(file='50.png')
    i60=PhotoImage(file='60.png')
    i70=PhotoImage(file='70.png')
    i80=PhotoImage(file='80.png')
    i90=PhotoImage(file='90.png')
    ipr=PhotoImage(file='proh.png')
    igr=PhotoImage(file='giro.png')



    # ThingSpeak
    channel_id = "2023127" # identificador del canal
    write_key = "YL0KTL5EIE6HF3CE" # key para enviar datos
    channel = thingspeak.Channel(id=channel_id, api_key=write_key)
    ianalisis=PhotoImage(file='analisis.png')
    boton_ts=ttk.Button(plano,image=ianalisis,command=envio_datos)
    boton_ts.place(x=30,y=230,width=60,height=60)
    
    #hilos y main loop
    fsenal = threading.Thread(target=id_senal)
    fsenal.start()
    threading.Timer(2,rst_pantalla,"1").start()
    ventana.mainloop()


######################################################
    # PRINCIPAL. INICIALIZACION DE HILOS
######################################################

#Ejecuta hilo función cámara 
threading.Thread(target=camara).start()
#Ejecutar hilo función joystick
threading.Thread(target=joystick).start()
##
threading.Thread(target=ventana).start()
threading.Thread(target=ctrl_velocidad).start()
threading.Thread(target=teclado).start()
            
    
#cv2.destroyAllWindows()
