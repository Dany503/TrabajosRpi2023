El archivo entrenamiento.py es el utilizado para entrenar la CNN. No se incluye el dataset en esta carpeta debido a su gran tamaño.

El archivo telescript.py implementa la funcionalidad principal de este proyecto.

Proyecto realizado por Carlos Álvarez Ruiz y Guillermo Gil García.

SDAA MIERA 2022/2023