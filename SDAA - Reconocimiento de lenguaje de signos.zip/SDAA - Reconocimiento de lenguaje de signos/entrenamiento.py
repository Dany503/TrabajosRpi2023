# Entrenamiento CNN
from numpy import loadtxt
from tensorflow import keras
import seaborn as sns
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report,confusion_matrix
from keras.preprocessing.image import ImageDataGenerator
from keras.callbacks import ReduceLROnPlateau

dataset_train = pd.read_csv('sign_mnist_train.csv')

y_train = dataset_train.label
X_train = dataset_train.drop('label', axis=1)

dataset_test = pd.read_csv('sign_mnist_test.csv')
y = dataset_test['label']
y_test = dataset_test.label
X_test = dataset_test.drop('label', axis=1)



#Escalamos los datos

X_train = X_train.astype('float32')
X_test = X_test.astype('float32')

X_train /= 255
X_test /= 255

X_train = X_train.values.reshape(27455, 28, 28, 1)
X_test = X_test.values.reshape(7172, 28, 28, 1)

#Pasamos las etiquetas a forma vectorial

from tensorflow.keras.utils import to_categorical
y_train = to_categorical(y_train, num_classes=25)
y_test = to_categorical(y_test, num_classes=25)

#Aumentamos el dataset con variaciones de las imágenes del data set (es una librería que viene implementada ya en keras) 


datagen = ImageDataGenerator( #El hecho de aumentar el dataset de esta manera previene el overfitting
        featurewise_center=False,  
        samplewise_center=False,  
        featurewise_std_normalization=False,  
        samplewise_std_normalization=False,  
        zca_whitening=False,  
        rotation_range=10,  # rota la imagen de forma completamente aleatoria
        zoom_range = 0.1, # hace zoom en la imagen aleatoriamente también
        width_shift_range=0.1,  # desplaza la imagen horizontalmente aleatoriamente
        height_shift_range=0.1,  # lo mismo verticalmente
        horizontal_flip=False,  # darles la vuelta no tiene sentido en nuestro trabajo (solo hemos implementado símbolos con la mano derecha)
        vertical_flip=False)  # verticalmente tampoco


datagen.fit(X_train) # aplica finalmente las rotaciones y los cambios de tamaño aleatorios especificados en "datagen"

from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Conv2D, MaxPool2D, Flatten, Dropout, BatchNormalization

# Esta función viene implementada en keras y permite reducir la agresividad de la red a la hora de aprender. Mejora la accuracy al prevenir el overfitting
learning_rate_reduction = ReduceLROnPlateau(monitor='val_accuracy', patience = 2, verbose=1,factor=0.5, min_lr=0.00001)
# Primero se aplica una red convolucional
model = Sequential() # Las funciones de activación son todas "relu" (funciona mejor para imágenes) excepto la última que es "softmax" (las salidas de la red suelen ser softmax)
model.add(Conv2D(75 , (3,3) , strides = 1 , padding = 'same' , activation = 'relu' , input_shape = (28,28,1)))
model.add(BatchNormalization()) #Esta capa convierte los pesos en una distribución normal (media 0, desviación 1). Hemos comprobado que mejora la accuracy
model.add(MaxPool2D((2,2) , strides = 2 , padding = 'same')) #Filtro de máximos (que además reduce el tamaño de la red al realizar desplazamientos de 2 en 2)
model.add(Conv2D(50 , (3,3) , strides = 1 , padding = 'same' , activation = 'relu'))
model.add(Dropout(0.2)) #Se descartan algunas de las neuronas (evita el overfitting)
model.add(BatchNormalization()) # Se vuelve a normalizar la salida
model.add(MaxPool2D((2,2) , strides = 2 , padding = 'same'))
model.add(Conv2D(25 , (3,3) , strides = 1 , padding = 'same' , activation = 'relu'))
model.add(BatchNormalization()) # Se vuelve a normalizar la salida
model.add(MaxPool2D((2,2) , strides = 2 , padding = 'same'))
model.add(Flatten()) # Se aplana la salida para introducirla en una red densamente conectada
model.add(Dense(units = 512 , activation = 'relu'))
model.add(Dropout(0.3)) # Se vuelve a aplicar un descarte aleatorio de neuronas
model.add(Dense(units = 25 , activation = 'softmax')) # En la última capa, la activación suele ser "softmax" para
model.compile(optimizer = 'adam' , loss = 'categorical_crossentropy' , metrics = ['accuracy']) # El optimizador adam daba buenos resultados, así que no hemos probado otros
model.summary()

#Parametros de entrenamiento

batch_size = 128
epochs = 20


history = model.fit(datagen.flow(X_train,y_train, batch_size = 128) ,epochs = 20 , validation_data = ( X_test, y_test) , callbacks = [learning_rate_reduction])
#Evaluacion

test_loss, test_acc = model.evaluate(X_test, y_test)

print('Test loss', test_loss)
print('Test accuracy', test_acc)

#Guardamos la red para meterla en la raspy
model.save_weights('CNN.h5')

#Generamos la matriz de confusión completa
predict_x = model.predict(X_test)
predictions = np.argmax(predict_x,axis=1)

predictions[:5]  

classes = ["Class " + str(i) for i in range(24)]
cm = confusion_matrix(y,predictions)

cm = pd.DataFrame(cm , index = [i for i in range(24)] , columns = [i for i in range(24)])

plt.figure(figsize = (15,15))
sns.heatmap(cm,cmap= "Blues", linecolor = 'black' , linewidth = 1 , annot = True, fmt='')
plt.show()
