# -*- coding: utf-8 -*-


#Telegram bot (dependencias)
import telepot
from telegram import Update
from telegram.ext import Updater
from telepot.loop import MessageLoop

#Clasificador (dependencias)

import cv2
import numpy as np
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Conv2D, MaxPool2D, Flatten, Dropout, BatchNormalization

#from PIL import Image

#Definición de la red convolucional
model = Sequential()
model.add(Conv2D(75 , (3,3) , strides = 1 , padding = 'same' , activation = 'relu' , input_shape = (28,28,1)))
model.add(BatchNormalization())
model.add(MaxPool2D((2,2) , strides = 2 , padding = 'same'))
model.add(Conv2D(50 , (3,3) , strides = 1 , padding = 'same' , activation = 'relu'))
model.add(Dropout(0.2))
model.add(BatchNormalization())
model.add(MaxPool2D((2,2) , strides = 2 , padding = 'same'))
model.add(Conv2D(25 , (3,3) , strides = 1 , padding = 'same' , activation = 'relu'))
model.add(BatchNormalization())
model.add(MaxPool2D((2,2) , strides = 2 , padding = 'same'))
model.add(Flatten())
model.add(Dense(units = 512 , activation = 'relu'))
model.add(Dropout(0.3))
model.add(Dense(units = 25 , activation = 'softmax'))

model.summary

model.load_weights('CNN.h5')

#Inicialización de la cámara
camera = cv2.VideoCapture(0)

#Inicialización de variables
palabra=[]
last_pred=''
lastlast_pred=''
lastlastlast_pred=''

def action(msg): 
    chat_id = msg['chat']['id'] 
    command = msg['text'] 

    print('Received: %s', command)

    if command == 'Hola': 
        telegram_bot.sendMessage (chat_id, str("Hola, el bot está funcionando")) 
    
    elif (command == 'Foto'):
        if(last_pred == lastlast_pred and lastlast_pred == lastlastlast_pred):
            telegram_bot.sendMessage(chat_id, str('La letra es: ')+str(last_pred))
            palabra.append(last_pred)
        else:
            telegram_bot.sendMessage(chat_id, str('No muevas la mano, inténtalo de nuevo...'))
    elif (command == 'Borra'):
        palabra.clear()
        telegram_bot.sendMessage(chat_id, str('Palabra reseteada'))
    elif (command == 'Traduce'):
        telegram_bot.sendMessage(chat_id, str('La palabra es: ')+str(' '.join(map(str,palabra))))
    elif (command == 'Manda la referencia'):
        telegram_bot.sendMessage(chat_id, str('¡Claro! Aquí tienes una imagen de referencia'))
        telegram_bot.sendPhoto(chat_id, photo=open('amer_sign2.png','rb'))
    else: 
        telegram_bot.sendMessage(chat_id, str('Comando no válido')) 


          
telegram_bot = telepot.Bot('TOKEN') #Cambiar aqui TOKEN por el token proporcionado por el bot que hayas creado
print (telegram_bot.getMe()) 

MessageLoop(telegram_bot, action).run_as_thread() 
print ('Up and Running....') 

while 1:
                                 
    #Obtenemos la imagen de la cámara                             
    ret, img = camera.read()
    #Dibujamos un rectángulo para saber dónde situar la mano                             
    cv2.rectangle(img, (200, 200), (400, 400), (255, 0, 0), 2)
    #Procesamos la imagen de esa zona para poder metérsela a la CNN                             
    cropped = img[200:400, 200:400]
    resized = (cv2.cvtColor(cv2.resize(cropped, (28, 28)), cv2.COLOR_RGB2GRAY)) / 255.0
    data = resized.reshape(-1, 28, 28, 1)
    #Hacemos la predicción                             
    model_out = model.predict([data])[0]
    label = np.argmax(model_out)

    #Traducimos la predicción a la letra que es
    if max(model_out) > 0.9:
        if label == 0:
            letter = "A"
        elif label == 1:
            letter = "B"
        elif label == 2:
            letter = "C"
        elif label == 3:
            letter = "D"
        elif label == 4:
            letter = "E"
        elif label == 5:
            letter = "F"
        elif label == 6:
            letter = "G"
        elif label == 7:
            letter = "H"
        elif label == 8:
            letter = "I"
        elif label == 10:
            letter = "K"
        elif label == 11:
            letter = "L"
        elif label == 12:
            letter = "M"
        elif label == 13:
            letter = "N"
        elif label == 14:
            letter = "O"
        elif label == 15:
            letter = "P"
        elif label == 16:
            letter = "Q"
        elif label == 17:
            letter = "R"
        elif label == 18:
            letter = "S"
        elif label == 19:
            letter = "T"
        elif label == 20:
            letter = "U"
        elif label == 21:
            letter = "V"
        elif label == 22:
            letter = "W"
        elif label == 23:
            letter = "X"
        elif label == 24:
            letter = "Y"
        
        #Mostramos por el terminal la letra para tener feedback visual
        print(letter)
                     
        #Almacenamos las anteriores predicciones para evitar bounces             
        lastlastlast_pred=lastlast_pred
        lastlast_pred=last_pred
        last_pred=letter
        
        
    #Mostramos la imagen
    cv2.imshow('img', img)

    if cv2.waitKey(25) & 0xFF == ord('q'):
        cv2.destroyAllWindows()
        break