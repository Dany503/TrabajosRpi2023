
from PIL import Image
#Importamos paquete tkinter
import tkinter as tk
from tkinter import ttk
from tkinter import messagebox

from time import sleep

#import packet picamera
from picamera import PiCamera

from sense_hat import SenseHat
sense=SenseHat()

import psutil

from os import remove
from os import path

import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.image import MIMEImage
from email.mime.text import MIMEText

modo_foto = "none"
numero_fotos = 0
numero_fotos_aceptadas = 0
image_path = ""
correo_electronico = ""

def efecto_normal():
    global modo_foto 
    modo_foto = "none"
def efecto_dibujos():
    global modo_foto
    modo_foto = "cartoon"
def efecto_antiguo():
    global modo_foto
    modo_foto = "washedout"
#Funcion imprimir texto
def ok_menu():
    global numero_fotos, correo_electronico
    correo_electronico = caja_correo_electronico.get()
    try:
        numero_fotos = int(caja_num_fotos.get())        
    except:
        messagebox.showerror("Error", "No se ha introducido un valor numérico")     
    else:
        if  ( numero_fotos < 1 ) :
            messagebox.showerror("Error", "Número de fotos a tomar tiene que ser mayor que 1")  
        else:
            ventana.destroy()
        
def guardar_si():
    global numero_fotos_aceptadas
    numero_fotos_aceptadas = numero_fotos_aceptadas + 1
    ventana2.destroy()
      
def guardar_no():
    if path.exists(image_path):
        remove(image_path)
    ventana2.destroy()
    
    
ventana = tk.Tk()
ventana.config(width=500, height=300)
ventana.title("Fotomaton")

#etiqueta introducir texto efecto de fotos
etiqueta_texto = ttk.Label(text="Elige el efecto de las fotos:")
etiqueta_texto.place(x=50, y=10)

#Declaracion boton foto sin efecto
boton_normal = ttk.Button(text="Normal", command=efecto_normal)
boton_normal.place(x=50, y=50)

#Declaracion boton foto blanco y negro
boton_dibujos = ttk.Button(text="Dibujos", command=efecto_dibujos)
boton_dibujos.place(x=150, y=50)

#Declaracion boton foto sepia
boton_antiguo = ttk.Button(text="Antiguo", command=efecto_antiguo)
boton_antiguo.place(x=250, y=50)

#etiqueta introducir texto numero de fotos
etiqueta_num_fotos = ttk.Label(text="Introduzca el número de fotos:")
etiqueta_num_fotos.place(x=50, y=150)

#etiqueta introducir texto numero de fotos
etiqueta_correo_electronico = ttk.Label(text="Introduzca su correo electrónico:")
etiqueta_correo_electronico.place(x=50, y=175)

#caja para introducir texto
caja_num_fotos = ttk.Entry()
caja_num_fotos.place(x=255, y=150, width=30)

caja_correo_electronico = ttk.Entry()
caja_correo_electronico.place(x=50, y=200, width=250)

#Declaracion boton Ok
boton_ok = ttk.Button(text="Ok", command=ok_menu)
boton_ok.place(x=50, y=250)

ventana.mainloop()

camera = PiCamera()
camera.resolution = (640,480)
camera.rotation = 180
camera.start_preview(fullscreen=False, window=(500,200,320,240))

#Hacer foto
bucle = True

while bucle:
    
    events = sense.stick.get_events()
    
    for event in events:
        
        if event.direction  == "middle":
            
            while numero_fotos_aceptadas < numero_fotos:
              
                cuenta_atras = ['3', '2', '1']
                
                for j in cuenta_atras:
                    sense.show_letter( j, text_colour=[0,0,255], back_colour=[128, 128, 128] )
                    sleep(1)
                    sense.clear()
                
                image_path = "/home/pi/Imagenes_fotomaton/Foto%s.jpeg" % str(numero_fotos_aceptadas+1)
                camera.image_effect = modo_foto
                #camera.annotate_text = "Effect: %s" % modo_foto
                camera.capture(image_path)
                
                im = Image.open(image_path)
                im.show()
                
                sleep(1)
                #Ventana aceptar foto
                ventana2 = tk.Tk()
                ventana2.config(width=300, height=200)
                ventana2.title("Esta es tu foto")
                
                #etiqueta introducir texto efecto de fotos
                etiqueta_texto = ttk.Label(text="¿Deseas guardarla?:")
                etiqueta_texto.place(x=50, y=70)
                
                #Declaracion boton foto sin efecto
                boton_guardar_si = ttk.Button(text="Sí", command=guardar_si)
                boton_guardar_si.place(x=50, y=100)
                
                #Declaracion boton foto blanco y negro
                boton_guardar_no = ttk.Button(text="No", command=guardar_no)
                boton_guardar_no.place(x=150, y=100)
            
                camera.stop_preview()                
                ventana2.mainloop()                               
                
                for proc in psutil.process_iter(): #para que se cierre la foto
                    
                    if proc.name() == "display" :
                        proc.kill()
                                       
                if numero_fotos_aceptadas >= numero_fotos-1:

                    bucle = False
                    sense.clear()
                
                camera.start_preview(fullscreen=False, window=(500,200,320,240))                 
                camera.image_effect = 'none'
                #camera.annotate_text = ''
                
camera.stop_preview()                    
                    
msg = MIMEMultipart()
msg['From']="fotomaton_mii_jrll@outlook.com"
msg['To']= correo_electronico
msg['Subject']="Fotos tomadas en el fotomatón"

text = MIMEText("¡Ya están aquí tus fotos tomadas en el fotomatón!")
msg.attach(text)

for i in range(numero_fotos):

    file = open("/home/pi/Imagenes_fotomaton/Foto%s.jpeg" % str(i+1), "rb")
    attach_image = MIMEImage(file.read())
    attach_image.add_header('Content-Disposition', 'attachment; filename = "Foto%s.jpeg"' % (i+1) )
    msg.attach(attach_image)
    
mailServer = smtplib.SMTP('smtp-mail.outlook.com',587)
mailServer.ehlo()
mailServer.starttls()
mailServer.ehlo()

Remitente = "CORREO_ELECTRONICO_REMITENTE"
Contraseña = "CONTRASEÑA_CORREO_REMITENTE"

mailServer.login(Remitente, Contraseña)
mailServer.sendmail(Remitente, correo_electronico, msg.as_string())
mailServer.close()

for i in range(numero_fotos):

    remove("/home/pi/Imagenes_fotomaton/Foto%s.jpeg" % str(i+1) )

camera.close()