
from picamera import PiCamera  #librerías de la camara
from sense_hat import SenseHat  #librería del Sense Hat
from time import sleep    #librería para las esperas
import cv2       #librería para el manejo de las imágenes
from PIL import Image     #librería para abrir la imagen
import pytesseract     #librería que nos permite realizar el reconocimiento de palabras a partir de imágenes
from pytesseract import Output
from gtts import gTTS    #Librería para realizar el text to speech de las palabras detectadas
import requests   #para mandar el mensaje a Telegram
import pygame #Reproducir la palabra por voz

# Vinculación con el bot de Telegram (bot personal)
def telegram_bot_sendtext(bot_message):

    bot_token = #Quitado por privacidad, es el bot que vamos a usar
    bot_chatID = #Quitado por privacidad, es el chat al que vamos a mandar el mensaje
    send_text = 'https://api.telegram.org/bot' + bot_token + '/sendMessage?chat_id=' + bot_chatID + '&parse_mode=Markdown&text=' + bot_message

    response = requests.get(send_text)

    return response.json()

while True:
    #Inicializamos Sense Hat y camara
    sense=SenseHat()
    camera = PiCamera()
    camera.resolution = (640,480)
    modo=0
    ciclo= True
    # el modo 1 servirá para ejecutar la lectura de datos, el 2 para terminar
    print("Pulse abajo para lector de palabras o arriba para cerrar")
    while ciclo and modo==0:
        events = sense.stick.get_events()
        for event in events:
            if event.direction  == "down":
                modo=1
                break
            elif event.direction  == "up":
                modo=2
                break
        
    if modo==1:
        #creo una pantallita para previsualizar la cámara
        camera.start_preview(fullscreen=False, window=(30,30,320,240))
        ciclo= True
        fin=0
        # cuando gire el jostick a la izquierda tomo la foto, la almaceno y cierro la cámara
        print("Pulse izquierda para sacar la foto")
        while ciclo and fin==0:
            events = sense.stick.get_events()
            for event in events:
                if event.direction  == "left":
                    fin=1
                    break
    

        camera.capture('/home/pi/Proyecto_2023/imagencap.jpg')
        camera.stop_preview()
        camera.close()
        #creo la lista "codigos" para almacenar las palabras leídas
        codigos=[]
        #leo la imagen
        img = cv2.imread('imagencap.jpg')

          # Uso el módulo pytesseract para detectar las palabras, se pone en inglés porque en español puede dar problemas
        d=pytesseract.image_to_data(img, lang='eng', output_type=Output.DICT)
        cant_cajas=len(d['text'])
        for i in range(cant_cajas):
        # Procesar solo con nivel de confianza mayor a X % (posiblemente se modifique)
            if int(d['conf'][i]) > 30:
                (text, x, y, w, h) = (d['text'][i], d['left'][i], d['top'][i], d['width'][i], d['height'][i])
                # no mostrar texto vacio
                if text and text.strip() != "":
                    img = cv2.rectangle(img, (x, y), (x + w, y + h), (255, 0, 0), 2)
                    img = cv2.putText(img, text, (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 1.0, (0, 255, 0), 3)
                    codigos.append(text)
            # Muestro lo detectado por pantalla y muestro la foto con un cuadrado azul rodeando la palabra y en verde la palabra detectada
        print(codigos)
        cv2.imwrite('editima.jpg', img)
        edit=Image.open('editima.jpg')
        edit.show()
        # Muestro las palabras leídas en el sense hat, dicto la palabra y envío la lista de palabras por telegram
        telemes="Lista de palabras leidas:"
        tam=len(codigos)
        
        for i in range(tam):
            sense.show_message(codigos[i],text_colour=[100,100,100]) #Muestro las palabras ppr el Sense Hat

#             if (ord(codigos[i][0])>64 and ord(codigos[i][0])<123) or (ord(codigos[i][0])>47 and ord(codigos[i][0])<58):
#                 ttsp=gTTS(text=codigos[i],lang='es',slow=False)
#             else:
#                 ttsp=gTTS(text="símbolo",lang='es',slow=False)

            # Hago un test to speech para recitar todas las palabras, guardo la pista de audio y después la reproduzco
            ttsp=gTTS(text=codigos[i],lang='es',slow=False)
            r=str(i)
            ttsp.save("vozpalab"+r+".mp3")
            pygame.mixer.init()
            pygame.mixer.music.load("vozpalab"+r+".mp3")
            pygame.mixer.music.play()

            # Hago la cadena de carácteres que mandaré por Telegram
            telemes=telemes+"\n"+codigos[i]
            sleep(1.5)
        if tam>0:    
            env = telegram_bot_sendtext(telemes) # envío el mensaje por el Bot de Telegram
        edit.close()
        
    elif modo==2: #termino el proceso
        break
    