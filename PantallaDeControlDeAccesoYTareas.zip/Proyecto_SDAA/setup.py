import ntplib
from calendar import weekday
from time import strftime, localtime, sleep

from threading import Thread, Lock

# Cámara Raspi o cámara OpenCV
def picamera_setup():
    from picamera import PiCamera
    from picamera.array import PiRGBArray
    global camera
    global rawCapture
    camera = PiCamera()
    camera.resolution = (432, 336)
    camera.framerate = 32
    #camera.rotation = 180
    camera.hflip = True
    rawCapture = PiRGBArray(camera, size=(432, 336))
    sleep(0.1)

def opencv_setup():
    import cv2
    global vid
    vid = cv2.VideoCapture(0)
    width, height = 640, 480
    vid.set(cv2.CAP_PROP_FRAME_WIDTH, width)
    vid.set(cv2.CAP_PROP_FRAME_HEIGHT, height)

def opencv_unsetup():
    vid.release()

def get_time(): # no llamar todo el rato o da errores
    dias_semana = ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"]
    ntp = ntplib.NTPClient()
    #while True:
    try:
        response = ntp.request('es.pool.ntp.org', timeout=10000)
    except:
        print("Error al coger tiempo")
        return
    time_2 = localtime(response.tx_time)
    dia_semana = weekday(int(strftime("%Y",time_2)),int(strftime("%m",time_2)),int(strftime("%d",time_2)))
    return (time_2, dias_semana[dia_semana])

class kept_time():
    def __init__(self):
        self.dias_semana = ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"]
        self.th_local_time = Thread(target=self.keep_time)
        self._lock = Lock()
        self.is_online = self.get_time_online()
        if not self.is_online:
            today = localtime()
            self.dia_semana = weekday(int(strftime("%Y",today)),int(strftime("%m",today)),int(strftime("%d",today)))
            
        

    def get_time_online(self): # no llamar todo el rato o da errores
        ntp = ntplib.NTPClient()
        #while True:
        try:
            self.response = ntp.request('es.pool.ntp.org', timeout=10000)
        except:
            print("Error al coger tiempo de Internet")
            return False
        time_2 = localtime(self.response.tx_time)
        self.dia_semana = weekday(int(strftime("%Y",time_2)),int(strftime("%m",time_2)),int(strftime("%d",time_2)))
        
        self.th_local_time.start()
        return True

    def keep_time(self):
        self.time_local = self.response.tx_time
        while True:
            self._lock.acquire()
            self.time_local = self.time_local + 1
            self._lock.release()
            sleep(1)

    def get_time(self):
        if self.is_online:
            self._lock.acquire()
            valor_return = localtime(self.time_local)
            self._lock.release()
        else:
            valor_return=today=localtime()
            self.dia_semana = weekday(int(strftime("%Y",today)),int(strftime("%m",today)),int(strftime("%d",today)))
            
        return (valor_return,self.dias_semana[self.dia_semana])




