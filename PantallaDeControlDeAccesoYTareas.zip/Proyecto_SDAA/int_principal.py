from calendar import weekday
import tkinter as tk
from tkinter import StringVar, ttk
import cv2
from PIL import Image, ImageTk # sudo apt install python3-pil.imagetk
#from picamera import PiCamera
#from picamera.array import PiRGBArray
from time import sleep, strftime, localtime
import ntplib 
from threading import Thread

import setup
from pyzbar.pyzbar import decode

class int_principal():
    def __init__(self):
        #th_time = Thread(target=self.time_to_tkinter)
        self.local_time = setup.kept_time()

        # Crea objeto root de TK + parámetros de la ventana principal
        self.root = tk.Tk()
        self.root.geometry('800x550') # Tamaño adecuado para la Raspi
        self.root.title('Pantalla principal')
        
        # preconfigurar columnas al tamaño de la ventana
        self.root.columnconfigure(list(range(8)),weight=1)
        self.root.rowconfigure(list(range(8)),weight=1)

        #self.time_tkinter = StringVar() # Variable con autoactualización de Tkinter
        #self.time_tkinter.set("Time uninitialized")
        self.time_tkinter = "Prueba"

        # Inicializar cámara
        # Opción con OpenCV en el pc
        #self.opencv_setup() # Cambiar en función de donde estés probando

        # Opción con PiCamera
        #setup.picamera_setup()
        self.camera = setup.camera
        self.rawCapture = setup.rawCapture

        # STILL TESTING: Copia local de variable global
        #self.vid = setup.vid

        self.label_img = ttk.Label()
        self.label_img.grid(row=0, column=1, rowspan=3)
        #self.opencv_read()

        # Inicializar elementos
        wrap_length = 400

        #th_time.start()
        
        #sleep(2)
        #marco = ttk.Frame(raiz, borderwidth=2, relief="raised", padding=(10,10))
        self.hora = ttk.Label(text=self.time_tkinter, font=("Arial", 28), justify="center", foreground="#a00", 
            wraplength=wrap_length) # .get() con stringvar
        #print(self.time_tkinter)
        self.hora.grid(row=1, column=0)
        self.time_to_tkinter()
        

        texto_bienvenida = ttk.Label(text="Bienvenido a la empresa!", font=("Arial", 30), wraplength=wrap_length, 
            justify="center")
        texto_bienvenida.grid(row=0, column=0)

        inserta_qr = ttk.Label(text="Enseña tu QR a la cámara para comenzar", foreground="#0a0", font=("Arial", 30),
            wraplength=wrap_length, justify="center")
        inserta_qr.grid(row=2, column=0)


        boton_prueba = ttk.Button(text='Salir', command=self.root.destroy)
        boton_prueba.place(x=50, y=50) # Pack, opciones simples relativas a lado. Grid como cuadricula. Place en absolutas
        boton_prueba.grid(row=3, column=0)

        self.decoded_qrs=None
        # Leer la cámara
        self.picamera_read()
        
        # Bucle para que salga la interfaz
        self.root.mainloop()

    def picamera_read(self):
        #for frame in self.camera.capture_continuous(self.rawCapture, format="bgr", use_video_port=True):
        
        self.camera.capture(self.rawCapture, format="bgr", use_video_port=True)
        # tomamos el array de numpy que reprsenta la image
        image = self.rawCapture.array
        self.rawCapture.truncate(0)
        image = self.decode_qr_from_img(image)
        img = Image.fromarray(image)
        imgtk = ImageTk.PhotoImage(image = img)
        self.label_img.imgtk = imgtk
        self.label_img.configure(image=imgtk)
        self.label_img.after(50, self.picamera_read)
        if self.decoded_qrs:
            self.kill_interface()
    
    def decode_qr_from_img(self,image):
        self.decoded_qrs = decode(image)
        if self.decoded_qrs:
            for decoded_qr in self.decoded_qrs: 
                (x, y, w, h) = decoded_qr.rect
                #cv2.rectangle(image, (x, y), (x + w, y + h), (255, 0, 0), 5)
                print(decoded_qr.data,'type:',decoded_qr.type)

        return image

    def kill_interface(self):
        self.root.destroy()

    def time_to_tkinter(self):
        time_2, dia_semana = self.local_time.get_time()
        time_display = strftime('%d/%m/%Y, %H:%M:%S',time_2)
        temp = "Hoy es " + dia_semana + " " + time_display
        #print(temp)
        self.time_tkinter = temp
        #print("Hoy es",dias_semana[dia_semana],time_display)
        self.hora.configure(text=self.time_tkinter)
        self.root.after(500, self.time_to_tkinter)
        #sleep(0.2)

    def opencv_read(self):
        cv2image= cv2.cvtColor(self.vid.read()[1],cv2.COLOR_BGR2RGB)
        img = Image.fromarray(cv2image)
        imgtk = ImageTk.PhotoImage(image = img)
        self.label_img.imgtk = imgtk
        self.label_img.configure(image=imgtk)
        self.label_img.after(20, self.opencv_read)


if __name__ == '__main__':
    int_principal_obj = int_principal()
