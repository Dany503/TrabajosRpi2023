# Función para coordinar todos los nodos

from int_principal import int_principal # from file import class
from int_user import int_user
import setup
from sys import exit
import pandas as pd

class main_class():
    def __init__(self):
        setup.picamera_setup() 
        #self.local_time = setup.kept_time()
        try:
            while True:
                # Crear variables globales para todos los archivos
                #setup.opencv_setup()
                #setup.picamera_setup()
                qr_succeeded = False
                while not qr_succeeded:
                    obj_int_principal = int_principal()
                    #breakpoint()
                    if obj_int_principal.decoded_qrs:
                        for decoded_qr in obj_int_principal.decoded_qrs: 
                            (x, y, w, h) = decoded_qr.rect
                            #cv2.rectangle(image, (x, y), (x + w, y + h), (255, 0, 0), 5)
                            print(decoded_qr.data,'type:',decoded_qr.type, 'en el main')
                            df=pd.read_csv('db/empleados.csv')
                            #breakpoint()
                            if int(decoded_qr.data) in df['ID'].values:
                                qr_succeeded = True



                int_user(int(decoded_qr.data))
        except KeyboardInterrupt:
            exit()




if __name__ == '__main__':
    main_obj = main_class()

