import tkinter as tk
from tkinter import RAISED, TOP, W, E, S, N, ttk
from time import strftime, sleep, localtime
from setup import kept_time
from threading import Thread
from sys import exit

from bs4 import BeautifulSoup
import requests

import pandas as pd
import thingspeak
import json

class int_user():
    def __init__(self, employee_number):
        # Crea objeto root de TK + parámetros de la ventana principal
        self.local_time = kept_time() # Para poder acceder bien a la clase desde fuera + threads
        th_weather = Thread(target=self.get_weather).start()
        sleep(5) # Timeout para que coja datos
        
        nombre = self.get_employee(employee_number)
        entrada_ayer, salida_ayer = self.get_ayer(employee_number)
        hora_entrada = self.get_entrada(employee_number)
        print(hora_entrada)


        self.root = tk.Tk()
        self.root.geometry('800x550')
        root_title = "Trabajador" + nombre + str(employee_number)
        self.root.title(root_title)
        #self.root.resizable(0,0) # Ventana de tamaño fijo
        self.time_tkinter="Prueba"
        self.texto_temp_interior = "Vacio"
        self.texto_temp_exterior = "Nada"
        self.texto_clima = "Oscuridad"

        self.root.columnconfigure(list(range(8)),weight=1)
        self.root.rowconfigure(list(range(8)),weight=1)


        wrap_length = 400
        texto_bienvenida = ttk.Label(text="Hola, "+ nombre, font=("Arial", 25), wraplength=wrap_length, 
            justify="center")
        texto_bienvenida.grid(row=0, column=0, columnspan=1)

        self.hora = ttk.Label(text=self.time_tkinter, font=("Arial", 28), justify="center", foreground="#a00") # .get() con stringvar
        #print(self.time_tkinter)
        self.hora.grid(row=0, column=4, columnspan=3)
        self.time_to_tkinter()

        texto_entrada = ttk.Label(text="Ent.: "+hora_entrada, font=("Arial", 25), wraplength=700, 
            justify="left")
        texto_entrada.grid(row=1, column=0, columnspan=2)

        texto_ayer = ttk.Label(text="Ayer: E: "+entrada_ayer + " S: " + salida_ayer, font=("Arial", 25), wraplength=700, 
            justify="left")
        texto_ayer.grid(row=1, column=3, columnspan=3)

        # El lambda evita que la función se invoque con el argumento nada más ejecutar el código
        boton_salir = tk.Button(text='Fichar salida', command= lambda: self.put_fichar(employee_number), height=3, 
            font=("Arial", 15))
        boton_salir.grid(row=3, column=6, columnspan=1)

        self.frame_tiempo = ttk.Frame(self.root, relief=RAISED)
        self.frame_tiempo.grid(row=4, column=6, rowspan=4, columnspan=3)

        self.label_t_exterior = ttk.Label(self.frame_tiempo, text=self.texto_temp_exterior, font=("Arial", 35), justify="center", 
            foreground="#0a0")
        self.label_t_exterior.pack(side=TOP)
        self.get_temp_exterior()

        self.label_clima = ttk.Label(self.frame_tiempo, text=self.texto_clima, font=("Arial", 25), justify="center", 
            foreground="#0a0", wraplength=150)
        self.label_clima.pack(side=TOP)
        self.get_clima()

        # Sección notas
        self.nota_index = 0 # dice cuantos elementos hay pero no apunta al último elemento lleno
        self.nota_buttons = ['']*6
        self.nota_labels = ['']*6
        
        
        #self.frame_notas = tk.Frame(self.root, relief=RAISED, bg="white") # repetir para cada línea
        style_test = ttk.Style()
        style_test.configure('FrameNotas.TFrame', background="white") # Nombre = NuevoNombre.TFrame (para frame, hay + casos)
        self.frame_notas = ttk.Frame(self.root, style='FrameNotas.TFrame', relief=RAISED)
        self.frame_notas.grid(row=3, column=0, rowspan=4, columnspan=6, sticky=W+E+S+N)
        self.frame_notas.columnconfigure(0,weight=1)
        self.frame_notas.columnconfigure(1,weight=8)
        self.frame_notas.rowconfigure(list(range(8)),weight=1)

        self.entrada_notas = ttk.Entry(self.root, font=("Arial", 30), width=25)
        self.entrada_notas.grid(row=8, column=0, columnspan=6, sticky=W)
        self.test_entrada = None
        #self.add_nota = tk.Button(self.root, text="Añadir", font=("Arial", 18), command= lambda: print(self.entrada_notas.get()))
        self.add_nota = tk.Button(self.root, text="Añadir", font=("Arial", 18), command= lambda: self.new_nota())
        self.add_nota.grid(row=8, column=6)

        #setup thingspeak
        channel_id = "2021284"
        read_key = "VN4YQI5NF4RLBEUQ"

        self.channel_read = thingspeak.Channel(id=channel_id, api_key=read_key)
        self.current_entry_id = 1
        Thread(target=self.read_channel).start()

        # Bucle para que salga la interfaz
        self.root.mainloop()


    def kill_interface(self):
        self.root.destroy()


    def time_to_tkinter(self):
        #time_2, dia_semana = setup.get_time()
        time_2, _ = self.local_time.get_time()
        time_2 = localtime()
        time_display = strftime('%H:%M:%S',time_2)
        date_display = strftime('%d/%m/%Y')
        temp =time_display + " - " + date_display
        self.time_tkinter = temp
        #print("Hoy es",dias_semana[dia_semana],time_display)
        self.hora.configure(text=self.time_tkinter)
        self.root.after(100, self.time_to_tkinter)

    def get_weather(self):
        ciudad = 'Sevilla'
        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'}
        while True:
            ciudad=ciudad+" weather"
            ciudad=ciudad.replace(" ","+")
            if self.local_time.is_online:
                res=requests.get(f'https://www.google.com/search?q={ciudad}&oq={ciudad}'
                                f'&aqs=chrome.0.35i39l2j0l4j46j69i60.6128j1j7&sourceid='
                                    f'chrome&ie=UTF-8',headers=headers)
                soup = BeautifulSoup(res.text,'html.parser')
                self.clima = soup.select('#wob_dc')[0].getText().strip()
                self.temp_ext = soup.select('#wob_tm')[0].getText().strip()

                #print(self.clima)
                #print(self.temp_ext+"°C")

            else:
                print("Error al coger tiempo")
                self.clima = 'Sin internet'
                self.temp_ext = "?"
            sleep(60)

    def get_temp_exterior(self):
        text = "Ext: " + str(self.temp_ext) + "ºC"
        self.texto_temp_exterior = text
        self.label_t_exterior.configure(text=self.texto_temp_exterior)
        self.frame_tiempo.after(60000, self.get_temp_exterior)

    def get_clima(self):
        text = self.clima
        self.texto_clima = text
        self.label_clima.configure(text=self.texto_clima)
        self.frame_tiempo.after(60000, self.get_clima)


    def get_employee(self, id):
        df = pd.read_csv('db/empleados.csv', index_col="ID")
        #print(df.loc[id]['nombre'])
        return (df.loc[id]['nombre'])

    def get_ayer(self, id):
        df = pd.read_csv('db/registro_horas.csv', index_col="ID", parse_dates=['fecha_entrada', 'fecha_salida'], dayfirst=True)
        if id not in df.index:
            hora_entrada=hora_salida='unspecified'
            df.loc[id]=[hora_entrada,hora_salida]
            df.to_csv('db/registro_horas.csv')
        else:
            pd_timestamp = df.loc[id]['fecha_entrada']
            timetuple = pd_timestamp.timetuple()
            hora_entrada = strftime('%H:%M',timetuple)

            pd_timestamp = df.loc[id]['fecha_salida']
            try:
                timetuple = pd_timestamp.timetuple()
                hora_salida = strftime('%H:%M',timetuple)
            except:
                hora_salida = pd_timestamp
            
        return (hora_entrada, hora_salida)

    def get_entrada(self, id): # TODO: Poner cuándo fue última entrada y salida
        #time_2 = localtime()
        time_2, _ = self.local_time.get_time()
        hora_entrada = strftime('%H:%M',time_2)
        self.date_entrada = strftime('%Y-%m-%d %H:%M:%S', time_2)
        df = pd.read_csv('db/registro_horas.csv', index_col="ID", parse_dates=['fecha_entrada'], dayfirst=True)
        time_salida = 'unspecified'
        df.loc[id] = [self.date_entrada, time_salida]  # Aquí cambiar para lo de multiple index
        df.to_csv('db/registro_horas.csv')
        return (hora_entrada)

    def put_fichar(self,id):
        #time_2, _ = setup.get_time()
        #time_2 = localtime()
        time_2, _ = self.local_time.get_time()
        #time_salida = strftime('%d-%m-%y %H:%M',time_2) # Un formato cualquiera
        date_salida = strftime('%Y-%m-%d %H:%M:%S', time_2)
        # Importar CSV con todo como fechas
        df = pd.read_csv('db/registro_horas.csv', index_col="ID", parse_dates=['fecha_entrada', 'fecha_salida'], dayfirst=True)
        # Añadir las fechas que quiero meter
        df.loc[id] = [self.date_entrada, date_salida] # Tambien con append. Aqui cambiar para hacer lo de multiple index
        # Cambio esta fila a timestamp de pd
        df.to_csv('db/registro_horas.csv')
        self.root.destroy()

    def new_nota(self, nota_in=None): 
        if self.nota_index < 6:
            if nota_in:
                nota=nota_in
            else:
                nota = self.entrada_notas.get()
            if len(nota)!=0:
                self.entrada_notas.delete(0, 'end')
                i=self.nota_index
                self.create_boton(i)
                #self.nota_buttons[self.nota_index] = ttk.Button(self.frame_notas, text="X", width=2, 
                #    command= lambda i=self.nota_index: self.delete_nota(i))
                #self.nota_buttons[self.nota_index].grid(row=self.nota_index, column=0)
                self.nota_labels[self.nota_index] = ttk.Label(self.frame_notas, text=nota, font=("Arial", 25), background="#fff", 
                    wraplength=600)
                self.nota_labels[self.nota_index].grid(row=self.nota_index, column=1, sticky=W)
                self.nota_index = self.nota_index + 1
                # Hacer con Pandas también, se actualiza al fichar fuera?
                #print(self.nota_index, self.nota_buttons)
        else:
            print("Límite de notas alcanzado")

    def delete_nota(self, i):
        self.nota_labels[i].destroy()
        self.nota_labels.pop(i)
        self.nota_index = self.nota_index - 1
        self.nota_buttons[i].destroy()
        self.nota_buttons.pop(i)
        self.nota_buttons.append('')
        self.nota_labels.append('')
        if self.nota_index > i:
            for j in range(0,self.nota_index):
                self.nota_labels[j].grid(row=j, column=1)
                self.nota_buttons[j].destroy()
                self.create_boton(j)

    def create_boton(self,i):
            self.nota_buttons[i] = ttk.Button(self.frame_notas, text="X", width=2, 
                command= lambda i=i: self.delete_nota(i))
            self.nota_buttons[i].grid(row=i, column=0)
        
    def read_channel(self):
        while True:
            try:
                response = self.channel_read.get()
            except:
                print("connection failed")

            data=json.loads(response)
#             print(data)
#             breakpoint()
            for i,feed in enumerate(data['feeds']):
                entry_id = feed['entry_id']
                if self.current_entry_id==entry_id:
                    self.current_entry_id = self.current_entry_id + 1
                    for j in range(1,7):
                        field='field'+str(j)
                        if feed[field]:
                            self.new_nota(nota_in=feed[field])
                
            sleep(2)

if __name__ == '__main__':
    obj_int_user = int_user(1)
