import qrcode
from picamera.array import PiRGBArray
from picamera import PiCamera
import time
import cv2
from pyzbar.pyzbar import decode
def capture_decodeqr_picamera():
    # inicializa la cámara
    camera = PiCamera()
    camera.resolution = (640, 480)
    camera.framerate = 32
    #camera.rotation = 180
    camera.hflip = True
    rawCapture = PiRGBArray(camera, size=(640, 480))
    #qr_detector = cv2.QRCodeDetector()
    # espera un tiempo a aque la cámara esté lista
    time.sleep(0.1)
     
    # capture frames from the camera
    for frame in camera.capture_continuous(rawCapture, format="bgr", use_video_port=True):
        # tomamos el array de numpy que reprsenta la image
        image = frame.array
        key = cv2.waitKey(1) & 0xFF
        rawCapture.truncate(0)
        #data, bbox, _ = qr_detector.detectAndDecode(image)
        decoded_qrs = decode(image)
        if decoded_qrs:
            for decoded_qr in decoded_qrs: 
                (x, y, w, h) = decoded_qr.rect
                cv2.rectangle(image, (x, y), (x + w, y + h), (255, 0, 0), 5)
                print(decoded_qr.data,'type:',decoded_qr.type)
            
        
        # muestra el frame
        cv2.imshow("Frame", image)
        # if there is a bounding box, draw one, along with the data
        #if(bbox is not None):
            #print(bbox)
            #for i in range(len(bbox)):
                #breakpoint()
                #cv2.line(image, tuple(bbox[i][0]), tuple(bbox[(i+1) % len(bbox)][0]), color=(255,0, 255), thickness=2)
            #cv2.putText(image, data, (int(bbox[0][0][0]), int(bbox[0][0][1]) - 10), cv2.FONT_HERSHEY_SIMPLEX,0.5, (0, 255, 0), 2)
           # if data:
#                 print("data found: ", data)
        # se pulsamos 'q' nos salimos del bucle
        if key == ord("q"):
             cv2.imwrite("/home/pi/foto.jpg",image) # guardamos la imagen
             break
    camera.close()
    cv2.destroyWindow("Frame")

def create_qrcode(data= range(10)): 
    # Data to be encoded
    
    for d in data:
        # Encoding data using make() function
        img = qrcode.make(d)
     
        # Saving as an image file
        img.save('qr_codes/'+str(d)+'.png')

#create_qrcode(['prueba'])
capture_decodeqr_picamera()