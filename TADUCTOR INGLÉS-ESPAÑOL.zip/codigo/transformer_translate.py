# -*- coding: utf-8 -*-
"""
Created on Tue Jan  3 01:09:31 2023

@author: C. Moreno Blázquez
"""

#%% Importamos librerías
import numpy as np
from keras_transformer import get_model, decode
import pickle
from pickle import load

# from google.colab import drive
np.random.seed(0)

#%% Leer set de entrenamiento
# drive.mount('/content/drive')
filename = 'english-spanish.pkl'

dataset = load(open(filename, 'rb'))
print(dataset[120000,0])
print(dataset[120000,1])

#%% Crear "tokens" (Separo todas las palabras de cada frase u oración del set 
# de entrenamiento). Cada palabra, tanto en inglés como español, es un token.
source_tokens = []
for sentence in dataset[:,0]:
  source_tokens.append(sentence.split(' '))
print(source_tokens[120000])

target_tokens = []
for sentence in dataset[:,1]:
  target_tokens.append(sentence.split(' '))
print(target_tokens[120000])

#%% Defino función para crear diccionario de tokens, la cual utilizaré para
# crear tanto un diccionario de entrada en inglés y español para el 
# entrenamiento, como uno de salida en español
# Creamos un diccionario de equivalencia entre palabras y números (tokens).
def build_token_dict(token_list):
  token_dict = {
      '<PAD>': 0,
      '<START>': 1,
      '<END>': 2
  }
  for tokens in token_list:
    for token in tokens:
      if token not in token_dict:
        token_dict[token] = len(token_dict)
  return token_dict

#%% Crear diccionario de entradas y salidas para relacionar palabras con números
# y otro para relacionar números con palabras, que es lo que necesitaremos para
# traducir finalmente.
source_token_dict = build_token_dict(source_tokens)
target_token_dict = build_token_dict(target_tokens)
target_token_dict_inv = {v:k for k,v in target_token_dict.items()}

print(source_token_dict)
print(target_token_dict)
print(target_token_dict_inv)
file1 = open("source.txt", "wb") 
pickle.dump(source_token_dict, file1)
file1.close
file1 = open("target.txt", "wb")
pickle.dump(target_token_dict, file1)
file1.close 
file1 = open("target_inv.txt", "wb") 
pickle.dump(target_token_dict_inv, file1)
file1.close

#%% Agregar start, end y pad a cada frase del set de entrenamiento
encoder_tokens = [['<START>'] + tokens + ['<END>'] for tokens in source_tokens]
decoder_tokens = [['<START>'] + tokens + ['<END>'] for tokens in target_tokens]
output_tokens = [tokens + ['<END>'] for tokens in target_tokens]

source_max_len = max(map(len, encoder_tokens))
target_max_len = max(map(len, decoder_tokens))

encoder_tokens = [tokens + ['<PAD>']*(source_max_len-len(tokens)) for tokens in encoder_tokens]
decoder_tokens = [tokens + ['<PAD>']*(target_max_len-len(tokens)) for tokens in decoder_tokens]
output_tokens = [tokens + ['<PAD>']*(target_max_len-len(tokens)) for tokens in output_tokens ]

print(encoder_tokens[120000])

#%% Ahora necesitamos representar cada token (vectores) numéricamente, pues es 
# el formato de entrada que necesita el Transformer. 
# Para ello, haremos uso de los diccionarios previamente creados.
encoder_input = [list(map(lambda x: source_token_dict[x], tokens)) for tokens in encoder_tokens]
decoder_input = [list(map(lambda x: target_token_dict[x], tokens)) for tokens in decoder_tokens]
output_decoded = [list(map(lambda x: [target_token_dict[x]], tokens)) for tokens in output_tokens]

print(encoder_input[120000])
     
#%% Crear la red transformer
model = get_model(
    token_num = max(len(source_token_dict),len(target_token_dict)), # máximo número de tokens (max del num. de palabras del diccion. en inglés y español)
    embed_dim = 32, # cantidad de elementos de cada vector (token) de entrada (tanto al codificador como decodificador). En este caso 32 valores en cada token.
    encoder_num = 2,    # número de codificadores (6 en elmodelo original)
    # encoder_num = 6,    # número de codificadores (6 en elmodelo original)
    decoder_num = 2,    # número de decodificadores (6 en elmodelo original)
    # decoder_num = 6,    # número de decodificadores (6 en elmodelo original)
    head_num = 4,   # número de bloques atencionales (8 en elmodelo original)
    # head_num = 8,   # número de bloques atencionales (8 en elmodelo original)
    hidden_dim = 128,   # número de neuronas en la capa oculta de la Red Neuronal del cod. y decod. (248 en elmodelo original)
    # hidden_dim = 248,   # número de neuronas en la capa oculta de la Red Neuronal del cod. y decod. (248 en elmodelo original)
    dropout_rate = 0.05,   # durante el Entrenamiento, el porcentaje de neuronas que desactivaremos en cada iteración para evitar Overfitting
    use_same_embed = False, # El modelo encontrará una manera diferente de representar las frases en inglés y español.
)

model.compile('adam', 'sparse_categorical_crossentropy')
model.summary()

#%% Entrenamiento
x = [np.array(encoder_input), np.array(decoder_input)]  # Entradas a la Red Tranformer para el entrnamiento --> las convierto en matrices
y = np.array(output_decoded)    # Salida de la Red Transformer es el output_decoder

# model.fit(x,y, epochs=30, batch_size=32)    # Comienza el entrenamiento con esta función...

filename = 'Transformer_translate_prueba1.h5'
model.load_weights(filename)

# Almacenamos el modelo
# model.save_weights("D:\Sistemas_Digitales_Avanzados\Transformer_translate_prueba3.h5")

#%% Una vez con el modelo entrenado, vamos a probar que tal funciona la 
# traducción. Para ello, creamos la función 'translate', donde introduciremos 
# una fase en inglés como parámetro de entrada y nos devuelve la traducción 
# en español como salida.
def translate(sentence):
  sentence_tokens = [tokens + ['<END>', '<PAD>'] for tokens in [sentence.split(' ')]] # Cogemos la frase, extraemos cada palabra
  tr_input = [list(map(lambda x: source_token_dict[x], tokens)) for tokens in sentence_tokens][0] # Codificamos cada palabra de la sentence con el diccion. de inglés a token num.
  decoded = decode( # Aquí decodificamos los tokens con la función 'decode', que ya viene en la librería de keras_transformers
      model, 
      tr_input, 
      start_token = target_token_dict['<START>'],  # Le indicamos que el token de comienzo
      end_token = target_token_dict['<END>'],    # Le indicamos que el token de fin
      pad_token = target_token_dict['<PAD>']     # Le indicamos que el token de PAD
  )
  
# La salida de 'decode' (del softmax) va a ser en formato numérico, por eso
# para obtener la traducción a español de numérico a español utilizamos el 
# diccionario inverso.
  print('Frase original: {}'.format(sentence))
  print('Traducción: {}'.format(' '.join(map(lambda x: target_token_dict_inv[x], decoded[1:-1])))) # El dato 0 es la palabra START y esa no interesa
     
#%% Validamos el modelo entrenado
translate('she likes chocolate ice cream and her mom likes the another one')
translate('we are well in our jobs but they earn more of money')
translate('he cooked many hamburgers for her birthday party')
translate('his friend is a bit noisy and i hate when he makes a lot')
translate('the children used to play football in the school')
translate('they had not been studying a lot for the test so they did not make the exam')