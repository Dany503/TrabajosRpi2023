import cv2
import pytesseract
from picamera.array import PiRGBArray
from picamera import PiCamera
from pytesseract import Output
import copy


# Interfaz
import tkinter as tk
from tkinter import ttk



# # flash
import RPi.GPIO as GPIO
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BOARD)
GPIO.setup(7,GPIO.OUT)

# # # # # # # red neuronal

import numpy as np
from keras_transformer import get_model, decode
import pickle

np.random.seed(0)
with open('source.txt', 'rb') as f:
    source_token_dict = pickle.load(f)
    
with open('target.txt', 'rb') as f:
    target_token_dict = pickle.load(f)
        
with open('target_inv.txt', 'rb') as f:
    target_token_dict_inv = pickle.load(f)

model = get_model(
    token_num = max(len(source_token_dict),len(target_token_dict)), # máximo número de tokens (max del num. de palabras del diccion. en inglés y español)
    embed_dim = 32, # cantidad de elementos de cada vector (token) de entrada (tanto al codificador como decodificador). En este caso 32 valores en cada token.
    encoder_num = 2,    # número de codificadores (6 en elmodelo original)
    # encoder_num = 6,    # número de codificadores (6 en elmodelo original)
    decoder_num = 2,    # número de decodificadores (6 en elmodelo original)
    # decoder_num = 6,    # número de decodificadores (6 en elmodelo original)
    head_num = 4,   # número de bloques atencionales (8 en elmodelo original)
    # head_num = 8,   # número de bloques atencionales (8 en elmodelo original)
    hidden_dim = 128,   # número de neuronas en la capa oculta de la Red Neuronal del cod. y decod. (248 en elmodelo original)
    # hidden_dim = 248,   # número de neuronas en la capa oculta de la Red Neuronal del cod. y decod. (248 en elmodelo original)
    dropout_rate = 0.05,   # durante el Entrenamiento, el porcentaje de neuronas que desactivaremos en cada iteración para evitar Overfitting
    use_same_embed = False, # El modelo encontrará una manera diferente de representar las frases en inglés y español.
)

filename = 'Transformer_translate_prueba1.h5'
#filename = 'D:\Sistemas_Digitales_Avanzados\Transformer_translate_prueba1.h5'
model.load_weights(filename)
espanol = " "
def translate(sentence):
  global espanol
  sentence_tokens = [tokens + ['<END>', '<PAD>'] for tokens in [sentence.split(' ')]] # Cogemos la frase, extraemos cada palabra
  tr_input = [list(map(lambda x: source_token_dict[x], tokens)) for tokens in sentence_tokens][0] # Codificamos cada palabra de la sentence con el diccion. de inglés a token num.
  decoded = decode( # Aquí decodificamos los tokens con la función 'decode', que ya viene en la librería de keras_transformers
      model, 
      tr_input, 
      start_token = target_token_dict['<START>'],  # Le indicamos que el token de comienzo
      end_token = target_token_dict['<END>'],    # Le indicamos que el token de fin
      pad_token = target_token_dict['<PAD>']     # Le indicamos que el token de PAD
  )
  
# La salida de 'decode' (del softmax) va a ser en formato numérico, por eso
# para obtener la traducción a español de numérico a español utilizamos el 
# diccionario inverso.
  print('Frase original: {}'.format(sentence))
  print('Traducción: {}'.format(' '.join(map(lambda x: target_token_dict_inv[x], decoded[1:-1])))) # El dato 0 es la palabra START y esa no interesa
  espanol=' '.join(map(lambda x: target_token_dict_inv[x], decoded[1:-1]))
  return espanol
 
# inicializa la cámara
camera = PiCamera()
camera.resolution = (640, 480)
camera.framerate = 32
camera.rotation = -90
camera.hflip = False
rawCapture = PiRGBArray(camera, size=(640, 480))



class Aplicacion:
    def __init__(self):
        self.estado =0
        self.english = "                     "
        self.ventana = tk.Tk()
        self.ventana.config(width=300, height=200)
        self.ventana.title("Traductor")

        self.boton_prev=ttk.Button(text="Previsualizar camara",command=self.previsualizacion)
        self.boton_prev.place(x=70, y=10)

        self.boton_cap=ttk.Button(text="Capturar",command=self.capturar)
        self.boton_cap.place(x=20, y=50)
        self.ingles=ttk.Label(text=self.english)
        self.ingles.place(x=120, y=50)
        self.ingles.configure(background="White",foreground="Black")

        self.ingles_in=ttk.Entry(textvariable=self.english)
        self.ingles_in.place(x=120, y=90)
        self.boton_corregir=ttk.Button(text="Corregir",command=self.corregir)
        self.boton_corregir.place(x=20, y=90)

        self.boton_trad=ttk.Button(text="Traducir",command=self.traducir)
        self.boton_trad.place(x=100, y=130)
        self.espanol=ttk.Label(text="                         ")
        self.espanol.place(x=50, y=170)
        self.espanol.configure(background="Green",foreground="Black")

        self.ventana.mainloop()
        
    def previsualizacion(self):
        if self.estado==0:
            self.estado=1
            camera.start_preview(fullscreen=False, window=(30,30,400,400))
            GPIO.output(7, GPIO.HIGH)
        else:
            print("Secuencia incorrecta\n")
        

    def capturar(self):
        if self.estado==1:
            self.estado=2
            output = np.empty((480, 640, 3), dtype=np.uint8)
            camera.capture(output, 'rgb')
            camera.stop_preview()
            GPIO.output(7, GPIO.LOW)
            image = copy.copy(output)
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            blur = cv2.GaussianBlur(gray, (3,3), 0)
            thresh = cv2.threshold(blur, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)[1]

            # Morph open to remove noise and invert image
            kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (3,3))
            opening = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, kernel, iterations=1)
            invert = 255 - opening

            # Perform text extraction
            data = pytesseract.image_to_string(invert, lang='eng', config='--psm 6')
            data_str=data
            while data_str.find('\n')>=0:
                data_str = data_str.replace("\n"," ")
            data_str = data_str.replace("n't"," not")
#             eliminar posibles espacios al principio y al final
            if data_str[0]==0:
                data_str=data_str[1:len(data_str)-1]
            if data_str[len(data_str)-1]:
                data_str=data_str[0:len(data_str)-2]
            self.english=''.join( x for x in data_str if x not in ".!?,|0123456789")
            print(self.english)
            self.ingles.config(text=self.english)
            cv2.imwrite('thresh.png', thresh)
            cv2.imwrite('opening.png', opening)
            cv2.imwrite('invert.png', invert)
        else:
            print("Secuencia incorrecta\n")

    def traducir(self):
        if self.estado==2:
            try:
                print("Traduciendo\n")
                self.trad=translate(self.english)
            except:
                self.trad="ERROR: Palabra desconocida"
            self.espanol.config(text=self.trad)
            self.estado=0
        else:
            print("Secuencia incorrecta\n")
        
        
    def corregir(self):
        self.english = self.ingles_in.get()
        while self.english.find('\n')>=0:
            self.english = self.english.replace("\n"," ")
        self.english = self.english.replace("n't"," not")
        self.ingles.config(text=self.english)

# Ventana
app=Aplicacion()