import pyzbar.pyzbar as pyzbar
import cv2
import mysql.connector

import smtplib
from email.mime.text import MIMEText

from flask import Flask, request, render_template

from threading import Thread

import paho.mqtt.client as mqtt
import thingspeak

app = Flask(__name__)

# Inicializa la cámara
camera = cv2.VideoCapture(0)


# Conexión a la base de datos de MariaDB
mydb = mysql.connector.connect(
  host="localhost",
  user="azcutia",
  passwd="azcutia",
  database="controlpasajeros"
);
        

# Crea un cursor para interactuar con la base de datos
mycursor = mydb.cursor()
    

# Variable para almacenar el último código QR leído
last_code = "hola"; #Inicializado con cualquier cadena, por ejemplo "hola".

def thingspeak_data(): #Función para el envío de datos del DHT11 (obtenidos mediante MQTT) a ThingSpeak
    
    # Creación de objeto Thingspeak
    channel = thingspeak.Channel(2013452, "IFFHBMXMGRDG0K8G")

    # Datos del servidor MQTT
    mqtt_server = "127.20.10.3" #"192.168.1.116"
    mqtt_port = 1883
    mqtt_topic = "temperatura"

    # Callback para cuando se conecta al servidor
    def on_connect(client, userdata, flags, rc):
        print("Conectado con código: " + str(rc))
        client.subscribe(mqtt_topic)

    # Callback para cuando se recibe un mensaje del tópico
    def on_message(client, userdata, msgThs):
        print("Mensaje recibido: " + msgThs.payload.decode())
        
        # Separamos los datos de temperatura y humedad
        dataThspk = msgThs.payload.decode().split(",")
        print(dataThspk[0])
        print(dataThspk[1])
        # Envío de los datos a ThingSpeak
        channel.update({'field1': dataThspk[0], 'field2': dataThspk[1]})

    # Inicializar el cliente MQTT
    client = mqtt.Client()
    client.on_connect = on_connect
    client.on_message = on_message
    client.connect(mqtt_server, mqtt_port, 60)

    # Bucle para mantener la conexión
    client.loop_forever()

def send_email(to): #Función para el envío de correo electrónico mediante Outlook
    try:
        # Tu dirección de correo y contraseña
        outlook_user = "trabajodeii2.2023@hotmail.com"
        outlook_password = "mssiyhnuyvbmcdlt"

        # Crear una conexión SMTP
        server = smtplib.SMTP('smtp.office365.com', 587)
        server.starttls()
        server.login(outlook_user, outlook_password)

        # Construye el mensaje
        from email.mime.text import MIMEText

        message = "Hola, adjunto encontrarás un enlace a un formulario para rellenar si eres positivo en covid: http://172.20.10.3:5000"
        msg = MIMEText(message)
        msg['From'] = "trabajodeii2.2023@hotmail.com"
        msg['To'] = to
        msg['Subject'] = "Información: Formulario COVID-19"

        # Envía el correo
        server.send_message(msg)

    except Exception as e:
        print("Error al enviar el correo a", to, ":", e)
    finally:
        # Cerrar la conexión
        server.quit()
    
def send_emailColindantes(to, asientof, vagonf): #Función para envío de correo a los asientos próximos a pasajero contagiado
    try:
        # Tu dirección de correo y contraseña
        outlook_user = "trabajodeii2.2023@hotmail.com"
        outlook_password = "mssiyhnuyvbmcdlt"

        # Crear una conexión SMTP
        serverCol = smtplib.SMTP('smtp.office365.com', 587)
        serverCol.starttls()
        serverCol.login(outlook_user, outlook_password)

        # Construye el mensaje
        from email.mime.text import MIMEText

        message = "Estimado pasajero. Sirva este correo para informarle que otro pasajero cercano a usted ha resultado positivo en Covid-19."
        msg = MIMEText(message)
        msg['From'] = "trabajodeii2.2023@hotmail.com"
        msg['To'] = to
        msg['Subject'] = "AVISO: COVID-19"

        # Envía el correo
        serverCol.send_message(msg)

    except Exception as e:
        print("Error al enviar el correo a", to, ":", e)
    finally:
        # Cerrar la conexión
        serverCol.quit()

@app.route('/')
def index():
    return render_template('form.html')

@app.route('/submit-form', methods=['POST'])
def submit_form():
    # Recibir los datos del formulario
    dniEnfermo = request.form.get('dni')
    print("DNI INTRODUCIDO :",dniEnfermo)

    # Conectar a la base de datos
#     mydb = mysql.connector.connect(
#         host="localhost",
#         user="azcutia",
#         passwd="azcutia",
#         database="controlpasajeros"
#     )

    # Crear cursor
    cursorEnfermo = mydb.cursor()

    # Realizar la consulta para recuperar el asiento y vagón del pasajero con el DNI especificado
    cursorEnfermo.execute("SELECT asiento, vagon FROM controldepasajeros WHERE dni = %s", (dniEnfermo,))
    resultEnfermo = cursorEnfermo.fetchone()

    if resultEnfermo:
        asientoEnfermo = resultEnfermo[0]
        vagonEnfermo = resultEnfermo[1]
        # Mostrar el asiento y el vagón por pantalla
        print("Asiento:", asientoEnfermo)
        print("Vagón:", vagonEnfermo)
        # Calcular los límites superior e inferior de los asientos colindantes
        limite_inferior = max(1, asientoEnfermo - 4) # Para no salirse de los límites del vagón
        limite_superior = min(32, asientoEnfermo + 4) # Para no salirse de los límites del vagón
        # Realizar la consulta para recuperar las direcciones de correo de los asientos colindantes
        cursorEnfermo.execute("SELECT gmail,asiento,vagon FROM controldepasajeros WHERE vagon = %s AND asiento BETWEEN %s AND %s", (vagonEnfermo, limite_inferior, limite_superior))
        result_correos = cursorEnfermo.fetchall()

        # Recorrer los resultados y enviar el correo a cada dirección
        for row in result_correos:
            correo = row[0]
            asiento_colindante = row[1]
            vagon_colindante = row[2]
            if asiento_colindante!=asientoEnfermo:
                print("Enviando correo a", correo, "asociado al asiento", asiento_colindante, "del vagón", vagon_colindante)
                send_emailColindantes(correo,asiento_colindante,vagon_colindante)

    else:
            print("No se ha encontrado ningún pasajero con ese DNI.")
            
    return "Form submitted"

def run_server():#Activación del servidor local de la raspberry
    if __name__ == '__main__':
        app.run(host='0.0.0.0',port=5000)

#Creación de hilos para la ejecución paralela de las distintas partes del código
server_thread = Thread(target=run_server)
thingspeak_thread = Thread(target=thingspeak_data)
server_thread.start()
thingspeak_thread.start()

        
while True:
    # Lee el siguiente frame de la cámara
    _, frame = camera.read()

    # Encuentra y decodifica códigos QR en el frame
    decoded_objects = pyzbar.decode(frame)

    # Recorre todos los objetos decodificados
    for obj in decoded_objects:
        # Extrae los datos del código QR
        data = obj.data.decode("utf-8")
        
        if data != last_code:
            last_code = data
            # Sustitución de los caracteres no deseados
            data = data.replace(";", " ")
            data = data.replace(":", " ")

            # Separa los datos en una lista
            data_list = data.split(" ")
            #print(data_list)

            # Inicializa las variables para almacenar los datos
            nombre = ""
            apellido = ""
            asiento = ""
            vagon = ""
            gmail = ""
            dni = ""

            # Recorre la lista y asigna los valores a las variables correspondientes
            for i in range(0, len(data_list), 2):
                if data_list[i] == "nombre":
                    nombre = data_list[i+1]
                elif data_list[i] == "apellido":
                    apellido = data_list[i+1]
                elif data_list[i] == "asiento":
                    asiento = data_list[i+1]
                elif data_list[i] == "vagon":
                    vagon = data_list[i+1]
                elif data_list[i] == "gmail":
                    gmail = data_list[i+1]
                elif data_list[i] == "dni":
                    dni = data_list[i+1]

            # Imprime los datos separados en la consola para conocer quién ha entrado
            print("Nombre:", nombre)
            print("Apellido:", apellido)
            print("Asiento:", asiento)
            print("Vagón:", vagon)
            print("Gmail:", gmail)
            print("DNI:", dni)
            
            asiento = int(asiento)
            vagon = int(vagon)
            
            # Inserta los datos en la tabla controldepasajeros
            sql = "INSERT INTO controldepasajeros (nombre, apellido, asiento, vagon, gmail, dni, tiempo) VALUES (%s, %s, %s, %s, %s, %s, CURRENT_TIMESTAMP)"
            val = (nombre, apellido, asiento, vagon, gmail, dni)
            mycursor.execute(sql, val)

            # Guarda los cambios en la base de datos
            mydb.commit()

            # Muestra un mensaje de confirmación por consola
            print(mycursor.rowcount, "registro insertado.")
            
            send_email(gmail)
            

            # Cierra la conexión a la base de datos
            #mydb.close()
        #print(data)

        


        # Encuentra las coordenadas del código QR
        (x, y, w, h) = obj.rect

        # Dibuja un rectángulo alrededor del código QR
        cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 0, 255), 2)

    # Muestra el frame en una ventana
    cv2.imshow("Lector QR", frame)
    

    # Salir de la aplicación con 'q'
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break
    
 
# Libera la cámara y destruye las ventanas
camera.release()
cv2.destroyAllWindows()
mydb.close()