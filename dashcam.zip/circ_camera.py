from picamera import PiCamera, PiCameraCircularIO
import time
from sense_hat import SenseHat
import numpy as np
import subprocess

crash = False

def init_camera(n_seconds):
    camera = PiCamera()
    camera.resolution = (640, 480)
    camera.rotation = 180
    camera.start_preview()
    time.sleep(2)
    camera.stop_preview()
    stream = PiCameraCircularIO(camera, seconds=n_seconds)
    
    return camera, stream


def take_photo(camera, filename, filename_counter):
    filename = filename + '_' + str(filename_counter) + '.jpg'
    camera.capture(filename)

def crash_video(camera, stream, filename):
    global crash

    filename_counter = 0
    camera.start_recording(stream, format='h264') 

    try:
        while True:
            if crash:
                time.sleep(4)
                stream.copy_to('crash.h264', seconds=10) 
                break

    finally:
        camera.stop_recording()
        print('Recording stopped')
    
        for i in range(5): 
            filename_counter = i
            take_photo(camera, filename, filename_counter)
            print('Photo ', i + 1, 'of 5 taken')
            time.sleep(2)
        
        camera.close()
            
        process = subprocess.Popen(['MP4Box', '-add', 'crash.h264', '-new', 'crash.mp4'],
                                   stdout=subprocess.PIPE,
                                   stderr=subprocess.PIPE)
        stdout, stderr = process.communicate()
        
        process.wait()

def check_gradient(lst):
    grads = np.gradient(lst)
    
    for num in grads:
        if np.abs(num) > 0.5:
            return True
    
    return False
                        

def get_accel_reading(hat, axis):
    accel = hat.get_accelerometer_raw()
    return accel[axis]

def crash_check():
    global crash
    x_buf = []
    y_buf = []
    z_buf = []
    
    sense = SenseHat()
    
    t1 = time.time()

    while True:
        x_buf.append(get_accel_reading(sense, 'x'))
        y_buf.append(get_accel_reading(sense, 'y'))
        z_buf.append(get_accel_reading(sense, 'z'))
        
        t2 = time.time()
        
        if (t2 - t1) > 0.2:
            if len(x_buf) > 1 and len(y_buf) > 1 and len(z_buf) > 1:
                if check_gradient(x_buf) or check_gradient(y_buf) or check_gradient(z_buf):
                    crash = True
                    print('Crash detected')
                    break
                else:
                    x_buf = []
                    y_buf = []
                    z_buf = []
                    t1 = time.time()                
    