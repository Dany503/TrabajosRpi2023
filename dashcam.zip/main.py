import botcommunication
import circ_camera
import threading
import lights

global crash
crash = False

filename = 'crash_pic'
camera, stream = circ_camera.init_camera(10)

camera_thread = threading.Thread(target=circ_camera.crash_video, args=(camera, stream, filename))
print('Camera_thread')
crash_thread = threading.Thread(target=circ_camera.crash_check)
print('Crash_thread')
comm_thread = threading.Thread(target=botcommunication.driver_function)
print('Bot_thread')

camera_thread.start()
crash_thread.start()
comm_thread.start()

crash_thread.join()
camera_thread.join()


alert_thread = threading.Thread(target=botcommunication.driver_function_accident)
alert_thread.start()
botcommunication.crash = True
lights.show_lights()


alert_thread.join()
comm_thread.join()