import time
from sense_hat import SenseHat

sense = SenseHat()
red = [255, 0, 0]
blue = [0, 0, 255]

red_light = [red] * 64
blue_light = [blue] * 64


def show_lights():
    for i in range(3):
        sense.show_message('Alarma !', text_colour=[100,100,100], scroll_speed=0.2)
        time.sleep(0.5)
        for t in range(5):
            sense.set_pixels(red_light)
            time.sleep(0.5)
            sense.set_pixels(blue_light)
            time.sleep(0.5)
    sense.clear()


