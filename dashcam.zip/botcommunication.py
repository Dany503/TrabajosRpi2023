import telegram
import asyncio
import time
user_id_list = []
offset = 0

crash = False

def driver_function():

    while not crash:
        asyncio.run(main())
        time.sleep(5)

def driver_function_accident():
    asyncio.run(send_accident_alert())
    return

async def main():
    
    global offset
    bot = telegram.Bot("TELEGRAM-BOT-TOKEN")
   
    async with bot:
        await bot.initialize()
        try:
            Update_tp = await bot.getUpdates(offset=offset, connect_timeout=100, pool_timeout=100, write_timeout=100, read_timeout=100)
        except:
            print('Timeout: get Update')
        for update in Update_tp:
            offset = update.update_id + 1
            chat_id = update.message.chat.id
            if update.message.text == '/Register':
                if chat_id not in user_id_list:
                    user_id_list.append(chat_id)
                    await bot.sendMessage(chat_id=chat_id, text="You are now registered for Updates!", connect_timeout=100, pool_timeout=100, write_timeout=100, read_timeout=100)
                else:
                    await bot.sendMessage(chat_id=chat_id, text="You are already registered!", connect_timeout=100, pool_timeout=100, write_timeout=100, read_timeout=100) 
        print(user_id_list)
        await bot.shutdown()


async def send_accident_alert():
    
    bot = telegram.Bot("TELEGRAM-BOT-TOKEN")
    
    async with bot:
        await bot.initialize()
        for us_id in user_id_list:
            await bot.send_message(us_id, "There has been an accident!")
            await bot.send_video(us_id, open("crash.mp4", "rb"), connect_timeout=100, pool_timeout=100, write_timeout=100, read_timeout=100)
            for i in range(5):
                photo_path = f"crash_pic_{i}.jpg"
                await bot.send_photo(us_id, open(photo_path, "rb"), connect_timeout=100, pool_timeout=100, write_timeout=100, read_timeout=100)
        await bot.shutdown()
    return

if __name__ == '__main__':
    asyncio.run(main())
    asyncio.run(send_accident_alert())