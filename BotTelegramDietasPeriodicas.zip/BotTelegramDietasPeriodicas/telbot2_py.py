from telethon.sync import TelegramClient
from telethon.tl.types import InputPeerUser
from os import path
import asyncio

# Logging configuration
logged = False


def login(phone, api_id, api_hash):
    global client
    client = TelegramClient(phone, int(api_id), api_hash)
    client.connect()
    if not client.is_user_authorized():  # If further authentication is needed via text
        client.send_code_request(phone)
        print('Further authentication required in order to log in, a code has been sent to the phone number.')
        client.sign_in(phone, input('Enter the code: '))
    print(f"Logged in as {client.get_me().username}!")


async def get_user(group):
    user_list = await client.get_participants(group)
    
    users_id = [user.id for user in user_list if user.id is not None]
    users_access_hash = [user.access_hash for user in user_list if user.access_hash is not None]
    users_names = [user.username for user in user_list if (user.username != '' and user.username is not None)]

    with open("users.txt", 'w+') as f:
        for i in range(len(users_names)):
            f.write(str(users_id[i])+":"+str(users_access_hash[i]) + ":" + str(users_names[i]) + "\n")
        print(f"{len(users_names)} users exported to {f.name}!")


async def send_messages(message, users, person):
    for user in users:
        id_hash_un = user.split(":")
        if (len(id_hash_un)<3):
            continue
        if (id_hash_un[2].lower().startswith(person.lower())):
            receiver = InputPeerUser(int(id_hash_un[0]), int(id_hash_un[1]))
            await client.send_message(receiver, message)
            print(f"Message sent to {person}.")


def save_credentials(*args):
    print('Saving credentials...')
    with open('creds.txt', 'w+') as f:
        for arg in args:
            f.write(f'{arg}\n')


def read_credentials():
    print('Reading credentials...')
    with open('creds.txt', 'r') as f:
        return [line for line in f.read().split('\n') if line != '']


def load_users():
    with open('users.txt', 'r') as f:
        return f.read().split('\n')


def send_message_via_telegram(message_to_send, person):
    global logged
    if not path.exists('creds.txt'):
        # Needed for login authentication
        print('Find these at https://my.telegram.org/ under API Development tools.')
        save_credentials(
            input('Phone # (EX: +11234560000): '),
            input('api_id (EX: 101340): '),
            input('api_hash (EX: ca123req3410fdls343207cc743): ')
        )

    if (not logged):
        credentials = read_credentials()
        login(*credentials)
        logged = True

    loop = asyncio.get_event_loop()

    loop.run_until_complete(get_user("grupocomidatrabajoelectronica"))
    loop.run_until_complete(send_messages(message_to_send, load_users(), person))

