import Comida
import Reconocimiento_facial
import tkinter as tk
from tkinter import ttk
import os
import sys
from datetime import datetime

text_results = None
generarComidas = None
verComidas = None
getComida = None
setComidas = None
log_in = None
sign_up = None
person = None
ok_button = None
listbox = None
mytext = None
myscroll = None

comidas = ("Almuerzo Lunes", "Cena Lunes", "Almuerzo Martes", "Cena Martes", "Almuerzo Miercoles", "Cena Miercoles", 
    "Almuerzo Jueves", "Cena Jueves", "Almuerzo Viernes", "Cena Viernes", "Almuerzo Sabado", "Cena Sabado", "Almuerzo Domingo", "Cena Domingo")

def gener_comidas():
    Comida.crear_dieta(person)
    script_dir = os.path.dirname(__file__)
    path = os.path.join(script_dir, "Datos/PlanningComidas_" + person + ".txt")
    if (os.path.exists(path)):
        with open(path, 'r') as file:
            global mytext
            global myscroll
            if (mytext is not None):
                mytext.pack_forget()
                myscroll.pack_forget()
            myscroll = ttk.Scrollbar(window, orient='vertical')
            mytext = tk.Text(window, yscrollcommand=myscroll.set, font=("Roboto", 9))
            mytext.insert(tk.END, ("Planificacion generada: \n" + file.read().replace("**", "")))
            mytext.bind("<Key>", lambda e: "break")
            myscroll.pack(side=tk.RIGHT, fill='y')
            mytext.pack()

def ver_Comidas():
    script_dir = os.path.dirname(__file__)
    path = os.path.join(script_dir, "Datos/PlanningComidas_" + person + ".txt")
    if (os.path.exists(path)):
        with open(path, 'r') as file:
            global mytext
            global myscroll
            if (mytext is not None):
                mytext.pack_forget()
                myscroll.pack_forget()
            myscroll = ttk.Scrollbar(window, orient='vertical')
            mytext = tk.Text(window, yscrollcommand=myscroll.set, font=("Roboto", 9))
            mytext.insert(tk.END, ("Planificacion generada: \n" + file.read().replace("**", "")))
            mytext.bind("<Key>", lambda e: "break")
            myscroll.pack(side=tk.RIGHT, fill='y')
            mytext.pack()
    else:
        text_results.config(text="No hay planificación")

def get_comidas():
    comida_actual = Comida.get_current_meal(person)
    text_results.config(font= ("Roboto", 15))
    text_results.config(text="Te toca comer: \n" + comida_actual.replace("**", ""))

def take_photo(name):
    if name.strip() != "":
        if (Reconocimiento_facial.add_person(name)):
            entry_name.pack_forget()
            text_results.config(text="Registro correcto. Bienvenid@, " + name)
            global person
            person = name
            sign_up.pack_forget()
            log_in.pack_forget()
            setComidas.pack(fill="x", padx="15", pady="5")
            ok_button.pack_forget()
    else:
        text_results.config(text="El nombre no puede estar vacio.")


def sign_up_f():
    global entry_name, ok_button
    text_results.config(text="Escribe tu usuario de Telegram.")
    entry_name = tk.Entry()
    entry_name.insert(0, "Tu nombre de Telegram")
    entry_name.bind("<FocusIn>", lambda e : entry_name.delete(0, "end"))
    entry_name.pack()
    ok_button = tk.Button(text="OK", font=("Roboto", 15), command=lambda: take_photo(entry_name.get()))
    ok_button.pack()

    pass


def log_in_f():
    global text_results
    global person
    person = Reconocimiento_facial.identify_person()
    if (person.lower().startswith("descon")):
        if (text_results is not None):
            text_results.config(text= "No se te ha reconocido, reintenta o pulsa en registrarte si no lo estas.")
            text_results.config(font= ("Roboto", 10))

    else:
        sign_up.pack_forget()
        log_in.pack_forget()
        script_dir = os.path.dirname(__file__)
        path = os.path.join(script_dir, "Datos/Planning_" + person + ".txt")
        #Si no se han seleccionado todavia los dias de planning, no se puede generar una dieta ni obtenerla.
        if (os.path.exists(path)):
            generarComidas.pack(fill="x", padx="15", pady="5")
            getComida.pack(fill="x", padx="15", pady="5")
            verComidas.pack(fill="x", padx="15", pady="5")
        setComidas.pack(fill="x", padx="15", pady="5")
        text_results.config(text= "Bienvenid@, " + person)
    text_results.update()

def set_comidas():
    global listbox
    if (mytext is not None):
                mytext.pack_forget()
                myscroll.pack_forget()
    if (listbox is None):
        if (text_results is not None):
                text_results.config(text= "Marque las comidas que desea planificar.")
                text_results.config(font= ("Roboto", 10))
        #Create the list box:
        generarComidas.pack_forget()
        getComida.pack_forget()
        verComidas.pack_forget()

        var = tk.Variable(value = comidas)
        listbox = tk.Listbox(window,
                                listvariable=var,
                                height=12,
                                selectmode=tk.MULTIPLE)
        listbox.pack(expand=True)
        setComidas.pack_forget()
        setComidas.pack(fill="x", padx="15", pady="5")
    else:
        script_dir = os.path.dirname(__file__)
        path = os.path.join(script_dir, "Datos/Planning_" + person + ".txt")
        #Open the file, not need to close it if using "with".
        with open(path,'w') as file:
            for i in listbox.curselection():
                file.write(listbox.get(i) + "\n")
        if (text_results is not None):
                text_results.config(text= "Planificacion ajustada.")
                text_results.config(font= ("Roboto", 10))
        listbox.pack_forget()
        setComidas.pack_forget()
        generarComidas.pack(fill="x", padx="15", pady="5")
        getComida.pack(fill="x", padx="15", pady="5")
        setComidas.pack(fill="x", padx="15", pady="5")
        verComidas.pack(fill="x", padx="15", pady="5")

        listbox = None




if __name__ == '__main__':

    #Automatized message sending:
    #TODO descomentar:
    generar_para_todos = True
    if (datetime.today().weekday() != 4):
        generar_para_todos = False
    
    # If it is friday, we need to check if there is not list already created. We compare
    # the last day of the year where the list was created with the current day of the year.
    last_day = Comida.get_last_day()
    today = datetime.now().timetuple().tm_yday
    if (today == last_day):
        generar_para_todos = False

    if generar_para_todos:
        #Es viernes y no se ha enviado todavia cada dieta para todo el mundo, se hace ahora:
        script_dir = os.path.dirname(__file__)
        # Iterate directory of images
        files = os.listdir(os.path.join(script_dir, "Images/"))
        if (len(files) > 0):
            for file_name in files:
                Comida.crear_dieta(file_name.split(".")[0])
            
    if len(sys.argv) > 1:
        exit()

    #Create the window:
    window = tk.Tk()
    window.title("Tus Dietas")
    window.geometry("600x480")

    #Add the title:
    title = tk.Label(text="Tus Dietas.", font=("Roboto", 25))
    title.pack()

    #Add a subtitle:
    subtitle = tk.Label(text="¿Que desea hacer?", font=("Roboto", 18))
    subtitle.pack()

    #Add button to log in.
    log_in = tk.Button(text="Entrar", font=("Roboto", 15), command=log_in_f, bg='#AAAAEE')
    log_in.pack(fill="x", padx="15", pady="5")

    #Add button to get current meal.
    sign_up = tk.Button(text="Registrarse", font=("Roboto", 15), command=sign_up_f, bg="#88EE88")
    sign_up.pack(fill="x", padx="15", pady="5")

    #Add button to generate meals.
    generarComidas = tk.Button(text="Nueva dieta semanal", font=("Roboto", 15), command=gener_comidas, bg='#88EE88')

    #Add button to view the meals of the week.
    verComidas = tk.Button(text="Ver comidas de la semana", font=("Roboto", 15), command=ver_Comidas, bg="#88EE88")

    #Add button to get current meal.
    getComida = tk.Button(text="¿Que me toca comer?", font=("Roboto", 15), command=get_comidas, bg="#88EE88")

    #Add button to change number of meals.
    setComidas = tk.Button(text="Ajustar dieta", font=("Roboto", 15), command=set_comidas, bg="#88EE88")

    text_results = tk.Label(text="", font=("Roboto", 18))
    text_results.pack()

    #Show the window and listen events:
    window.mainloop()



