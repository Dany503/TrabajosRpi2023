import cv2
import face_recognition
import os
from time import sleep


def get_encodings():
    face_image_encodings = []
    script_dir = os.path.dirname(__file__)
    # Iterate directory of images
    files = os.listdir(os.path.join(script_dir, "Images/"))
    if (len(files) < 1):
        return None
    for name_file in files:
        path = os.path.join(script_dir, "Images/"+name_file)
        image = cv2.imread(path)
        #Locate the face
        face_loc = face_recognition.face_locations(image)[0]
        #Get the encoding and append it to the encodings list
        face_image_encodings.append(face_recognition.face_encodings(image, known_face_locations=[face_loc])[0])
    return face_image_encodings

def get_face_frame():
    cap = cv2.VideoCapture(0)

    while True:
        _, frame = cap.read()
        frame_orig = frame
        face_location = face_recognition.face_locations(frame, model="hog")
        if len(face_location) > 0:
            face_location = face_location[0]
            color = (125, 220, 0)
            cv2.rectangle(frame, (face_location[3], face_location[0]), (face_location[1], face_location[2]), color, 2)
            cv2.putText(frame, "Place the face in the center of the image", (face_location[3], face_location[2] + 20), 2, 0.5, (255, 255, 255), 1)
            meanX = (face_location[1] + face_location[3])//2
            limitLeft = int(cap.get(3)*0.4)
            limitRight = int(cap.get(3)*0.6)
            if (meanX > limitLeft) and (meanX < limitRight):
                cap.release()
                try:
                    cv2.destroyWindow("Frame")
                except:
                    pass
                return frame_orig, [face_location]

        cv2.imshow("Frame", frame)
        if cv2.waitKey(5) & 0xFF == 27:
            cap.release()
            break

    
def identify_person():
    #First get encodings from each saved photo.
    face_image_encodings = get_encodings()
    if (face_image_encodings is None):
        return "Desconocido"
        
    frame, face_locations = get_face_frame()


    script_dir = os.path.dirname(__file__)
    # Iterate directory of images
    files = os.listdir(os.path.join(script_dir, "Images/"))

    # face_locations = face_recognition.face_locations(frame, model="hog")
    if (len(face_locations) < 1):
        return "Desconocido"
    if face_locations != []:
        for face_location in face_locations:
            face_frame_encodings = face_recognition.face_encodings(frame, known_face_locations=[face_location], model="small")[0]
            result = face_recognition.compare_faces(face_image_encodings, face_frame_encodings)
            detected = False
            for i in range(len(face_image_encodings)):
                if result[i] == True:
                    detected = True
                    text = files[i].split(".")[0]
                    break
            if not detected:
                text = "Desconocido"

    return text

take_picture = False

def take_pic(event, arg1, arg2, arg3, arg4):
    if event == cv2.EVENT_LBUTTONDOWN:
        global take_picture
        take_picture = True

def add_person(name):
    cap = cv2.VideoCapture(0)
    _, frame = cap.read()
    cv2.putText(frame, "Place the face in the center of the image and touch the screen", (0, 30), 2, 0.5, (0, 0, 0), 1)
    cv2.imshow("Frame", frame)
    cv2.setMouseCallback("Frame", take_pic)
    while True:
        _, frame = cap.read()
        cv2.putText(frame, "Place the face in the center of the image and touch the screen", (0, 30), 2, 0.5, (0, 0, 0), 1)
        cv2.imshow("Frame", frame)
        if (cv2.waitKey(5) & 0xFF == 32) or take_picture:
            script_dir = os.path.dirname(__file__)
            # Iterate directory of images
            path = os.path.join(script_dir, "Images/"+name + ".jpg")
            cv2.imwrite(path, frame)
            cap.release()
            cv2.destroyWindow("Frame")
            break
    return True
