import os
import numpy as np
import telbot2_py
from datetime import datetime
from random import randint

name_person_global = ""

#Function to read the files containing the foods information: Names and times eaten.
#Param: File name.
#Return: list of strings containing food names and list of integers containing times eaten.
def read_file(name_file):
    #Initialize lists
    names_r = []
    times_r = []

    #Prepare file path with current directory and file name
    script_dir = os.path.dirname(__file__)
    path = os.path.join(script_dir, "Datos/"+name_file)

    #Open the file, not need to close it if using "with".
    with open(path,'r') as file:
        #Read the first line
        line = file.readline()
        #While the line is not empty:
        while(len(line) > 0):
            #The file is written following: Food - Times
            #Append the name to the list
            names_r.append(line.split("-")[0])
            #Append the times to the list, convert it to int.
            times_r.append(int(line.split("-")[1]))
            #Read the next line.
            line = file.readline()
    #Return the lists
    return names_r, times_r

#Function to get the las day the list was created.
def get_last_day():
    script_dir = os.path.dirname(__file__)
    path = os.path.join(script_dir, "Datos/LastDay.txt")
    #Open the file, not need to close it if using "with".
    with open(path,'r') as file:
        line = file.readline()
        return int(line)

#Function to save the last day the list was created in the file.
def set_last_day():
    script_dir = os.path.dirname(__file__)
    path = os.path.join(script_dir, "Datos/LastDay.txt")
    #Open the file, not need to close it if using "with".
    with open(path,'w') as file:
        file.write(str(datetime.today().timetuple().tm_yday))

#Function to save the modified data in files.
def save_data(names_p, times_p, names_a, times_a):
    script_dir = os.path.dirname(__file__)
    path = os.path.join(script_dir, "Datos/Principal_" + name_person_global + ".txt")
    #Open the file, not need to close it if using "with".
    with open(path,'w') as file:
        for i in range(len(names_p)):
            file.write(names_p[i] + " - " + str(times_p[i]) + "\n")
    path = os.path.join(script_dir, "Datos/Acompanante_" + name_person_global + ".txt")
    #Open the file, not need to close it if using "with".
    with open(path,'w') as file:
        for i in range(len(names_a)):
            file.write(names_a[i] + " - " + str(times_a[i]) + "\n")

#Function to increase the times a food has been eaten.
def increase_times(principales, acompanantes):
    script_dir = os.path.dirname(__file__)

    path = os.path.join(script_dir, "Datos/Principal_" + name_person_global + ".txt")
    if (os.path.exists(path)):
        names_p, times_p = read_file("Principal_" + name_person_global + ".txt")
    else:
        names_p, times_p = read_file("Principal_Generico.txt")

    path = os.path.join(script_dir, "Datos/Acompanante_" + name_person_global + ".txt")

    if (os.path.exists(path)):
        names_a, times_a = read_file("Acompanante_" + name_person_global + ".txt")
    else:
        names_a, times_a = read_file("Acompanante_Generico.txt")
        
    for i in range(len(principales)):
        index_p = names_p.index(principales[i])
        times_p[index_p] = times_p[index_p] + 1

        index_a = names_a.index(acompanantes[i])
        times_a[index_a] = times_a[index_a] +1
    
    save_data(names_p, times_p, names_a, times_a)

#Function to generate the text to send to the user.
def generate_text(picked_principal, picked_acompanante):
    full_text = "Hola " + name_person_global + ", " + "tus comidas para la próxima semana serán: \n"
    
    script_dir = os.path.dirname(__file__)
    path = os.path.join(script_dir, "Datos/Planning_" + name_person_global + ".txt")
    #Open the file, not need to close it if using "with".
    with open(path,'r') as file:
        planning = file.readlines()

    for i in range(len(picked_principal)):
        full_text =  full_text + "\n**" + planning[i] + "**" + picked_principal[i].strip() + " + " + picked_acompanante[i].strip() + "\n"  
    #Este texto es el que se envia por telegram.
    telbot2_py.send_message_via_telegram(full_text, name_person_global)
    #Save into txt:
    path = os.path.join(script_dir, "Datos/PlanningComidas_" + name_person_global + ".txt")
    #Open the file, not need to close it if using "with".
    with open(path,'w') as file:
        file.write(full_text)

#Function to generate the meals.
def generate_meals(number_of_foods):
    script_dir = os.path.dirname(__file__)

    path = os.path.join(script_dir, "Datos/Principal_" + name_person_global + ".txt")
    if (os.path.exists(path)):
        names_p, times_p = read_file("Principal_" + name_person_global + ".txt")
    else:
        names_p, times_p = read_file("Principal_Generico.txt")

    path = os.path.join(script_dir, "Datos/Acompanante_" + name_person_global + ".txt")

    if (os.path.exists(path)):
        names_a, times_a = read_file("Acompanante_" + name_person_global + ".txt")
    else:
        names_a, times_a = read_file("Acompanante_Generico.txt")


    #The meals will be generated with a main and a side food. We will pick between the less repeated foods, randomly.
    principal_sorted_indixes = np.argsort(times_p).tolist()
    acompanante_sorted_indixes = np.argsort(times_a).tolist()

    #We suppose that we have at least 4 more foods stored in the data base that the number of meals requested.
    #We pick the indices of the (number_of_foods+4) foods less repeated.
    principal_sorted_indixes = principal_sorted_indixes[0: number_of_foods+4]
    acompanante_sorted_indixes = acompanante_sorted_indixes[0: number_of_foods+4]

    picked_principal = []
    picked_acompanante = []

    #We pick randomly the indices of the foods less repeated and add to the list of foods picked.
    for i in range(0, number_of_foods):
        #Random index to pick:
        random_int = randint(0, len(principal_sorted_indixes)-1)
        #Add to the picked food list the food with the index given by de random_int as index of the less repeated indices.
        picked_principal.append(names_p[principal_sorted_indixes[random_int]])
        #Remove this index to avoid repetition
        principal_sorted_indixes.pop(random_int)

        #A new random int for the side meals.
        random_int = randint(0, len(acompanante_sorted_indixes)-1)
        #Add to the picked food list the food with the index given by de random_int as index of the less repeated indices.
        picked_acompanante.append(names_a[acompanante_sorted_indixes[random_int]])
        #Remove this index to avoid repetition
        acompanante_sorted_indixes.pop(random_int)

    generate_text(picked_principal, picked_acompanante)
    increase_times(picked_principal, picked_acompanante)


#Main function, called when script is executed.
def crear_dieta(name_person):
    global name_person_global
    name_person_global = name_person
    
    #Generate meals list:
    script_dir = os.path.dirname(__file__)
    path = os.path.join(script_dir, "Datos/Planning_" + name_person + ".txt")
        #Open the file, not need to close it if using "with".
    with open(path,'r') as file:
        n_meals = len(file.readlines())
        generate_meals(n_meals)
        #Update the last day
        set_last_day()



def get_current_meal(name_person):
    comida = "No tienes nada planificado para ahora."
    dias = ("Lunes", "Martes", "Miercoles", "Jueves", "Viernes", "Sabado", "Domingo")
    today = dias[datetime.now().weekday()]
    hora = datetime.now().hour
    almuerzo = (hora <= 16)
    script_dir = os.path.dirname(__file__)
    path = os.path.join(script_dir, "Datos/PlanningComidas_" + name_person + ".txt")
    if (os.path.exists(path)):
        with open(path, 'r') as file:
            text = file.read()
            if almuerzo:
                index = text.find("Almuerzo " + today)
                if (index > -1):
                    comida = text[index:text.find("\n", (index+len("Almuerzo " + today)+2))]
            else:
                index = text.find("Cena " + today)
                if (index > -1):
                    comida = text[index:text.find("\n", (index+len("Cena " + today)+2))]
    return comida
    


